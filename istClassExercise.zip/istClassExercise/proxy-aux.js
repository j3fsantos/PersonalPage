/// Useful auxiliary functions (used to be common.js)
// verbose(...) uses console to log messages.
var turn_on_verbose;
var turn_off_verbose;
var verbose;

(function(){
    var verbose_flag = false;
    turnOnVerbose = function () { verboseFlag = true; };
    turnOffVerbose = function () { verboseFlag = false; };
    verbose = function () {
        if (!verboseFlag) {
            return;
        }
        var log = new String();
        for (var i = 0; i < arguments.length; i++) {
            log += arguments[i];
        }
        if (arguments.length > 0) {
            console.log(log);
        }
        return;
    };
   //verbose = function() {}
})();

//Turn on verbose
turnOnVerbose();

// handle_id_gen() generate a fresh interger id for various usage.
var handleIdGen = (function () {
        var idCounter = 0;
        return (function () {return idCounter++;});  
        })();

// msg_id_gen() generate a fresh interger id for various usage.
var msgIdGen = (function () {
        var idCounter = 0;
        return (function () {return idCounter++;});
        })();

//Timers code

var startTime;

function timerStart(){
    startTime = (new Date()).getTime();
}

function timerEndInternal(){
    var endTime = (new Date()).getTime();
    var time = endTime - startTime;
    var logDiv = document.getElementById("log");
    logDiv.innerHTML="Consumed time: " + time + "ms.";
}

function timerEnd(){
    var t = setTimeout("timerEndInternal()",00);
}

// My auxiliary methods/functions

function copyObject(from, to){
    for(var prop in from) {
       if(from.hasOwnProperty(prop)) to[prop] = from[prop];   
    }
}

var binaryOperatorsTable = { 
	'+':   function(op1, op2) { return op1 + op2; }, 
	'-':   function(op1, op2) { return op1 - op2; }, 
	'<':   function(op1, op2) { return op1 < op2; },
    '>':   function(op1, op2) { return op1 > op2; },
    '>=':  function(op1, op2) { return op1 >= op2; },
    '<=':  function(op1, op2) { return op1 - op2; },    
	'*':   function(op1, op2) { return op1 * op2; }, 
	'/':   function(op1, op2) { return op1 / op2; }, 
	'&':   function(op1, op2) { return op1 & op2; }, 
	'|':   function(op1, op2) { return op1 | op2; }, 
	'%':   function(op1, op2) { return op1 % op2; }, 
	'^':   function(op1, op2) { return op1 ^ op2; }, 
	'<<':  function(op1, op2) { return op1 << op2; }, 
	'>>':  function(op1, op2) { return op1 >> op2; }, 
	'>>>': function(op1, op2) { return op1 >>> op2; }, 
};

var unaryOperatorsTable = { 
	'++':   function(operand) { return ++operand; }, 
	'--':   function(operand) { return --operand; }, 
	'-' :   function(operand) { return -operand;  },
	'+' :   function(operand) { return operand;   } 
};

var buildArgumentsArray = function(args, index) { 
   var argsLen = args.length; 
   var len = argsLen - index; 
   
   if (len == 0) return null; 
   
   var argsRet = new Array(argsLen-index);
   for (var i=index, j=0; i<argsLen; i++, j++) { 
      argsRet[j] = args[i]; 
   } 
   
   return argsRet; 
};
