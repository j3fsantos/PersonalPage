var myhouseLat; 
var myhouseLong;
var myhouse;
var neighborhoods; 
var markers = [];
var map;

function initialize() {
  
   myhouseLat = 38.7; 
   myhouseLong = -9.25; //put as it is
   myhouse = new google.maps.LatLng(myhouseLat,myhouseLong);
 
   var mapOptions = {
      zoom: 12,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      center: myhouse
   };
 
   map = new google.maps.Map(iframe.getElementById("map_canvas"), mapOptions);
   
    markers.push(new google.maps.Marker({
      position: myhouse,
      map: map,
      draggable: false,
      animation: google.maps.Animation.DROP
   }));
   
}
 
function drop() {
   var auxLat; 
   var auxLong; 
   var numberOfMarkers = parseFloat(document.getElementById("numberOfMarkers").value);  // as it is 
   for (var i = 0; i < numberOfMarkers; i++) {  // i as it is
      auxLat = myhouseLat + (Math.random()*0.1-0.05);  // as it is 
      auxLong = myhouseLong + (Math.random()*0.1-0.05);  // as it is
      addMarker(new google.maps.LatLng(auxLat,auxLong)); 
   }
}
 
function addMarker(coords) {
   markers.push(new google.maps.Marker({
      position: coords,
      map: map,
      draggable: false,
      animation: google.maps.Animation.DROP
   }));
}