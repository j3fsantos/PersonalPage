OBJ<__k><p^{2}: PRIM^{3}, 
q^{0}: FUN<__k.(PRIM^{3}) ->^{2} PRIM^{3}>^{0}>^{0}