$(function() {

  /*
     * var div1, div2, div3, h, l; 
     * h = 1; 
     * upgVar(h,  '2'); 
     * div1 = document.createElement('div');
     * div2 = document.createElement('div');
     * div3 = document.createElement('div');
     * div1.appendChild(div2);
     * if (h) {
     *    div3.appendChild(div2);
     * }
     * l = div1.childNodes.length;
     */    

	test('createElement + appendChild - 1', function() {
		var _lev_this, _val_6, _lev_6, _val_5, _lev_5, _val_4, _lev_4, _val_3, _lev_3, _val_2, _lev_2, _pc_holder_1, _val_1, _lev_1, _val_0, _lev_0, _pc, _lev_ctxt, _ret;
		var div1, div2, div3, h, l, nvar_0, _lev_div1, _lev_div2, _lev_div3, _lev_h, _lev_l, _lev_nvar_0;
		_pc = _runtime.lat.bot;
		_lev_this = _pc;
		_lev_div1 = _pc;
		_lev_div2 = _pc;
		_lev_div3 = _pc;
		_lev_h = _pc;
		_lev_l = _pc;
		_lev_nvar_0 = _pc;
		_runtime.createShadowWindowProperties();
		if (!_runtime.lat.leq(_pc, _lev_h)) {
			_runtime.diverge();
		}
		_lev_h = _pc;
		h = 1;
		if (!_runtime.lat.leq(_pc, _lev_h)) {
			_runtime.diverge();
		}
		_lev_h = _runtime.lat.lub(_lev_h, '2');
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
			_val_6 = document['createElement']('div');
			_lev_6 = _iflow_sig._updtLab(_val_6, _lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
		} else {
			_lev_6 = _pc;
			_val_6 = document;
			while (!_runtime.hasOwnProperty(_val_6, 'createElement')) {
				_lev_6 = _runtime.lat.lub(_lev_6, _val_6._lev_proto, _val_6._lev_struct);
				_val_6 = _val_6._proto;
			}
			if (_val_6) {
				_lev_6 = _runtime.lat.lub(_lev_6, _val_6[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_6, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'div', _lev_ctxt);
			_val_6 = _ret._val;
			_lev_6 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div1)) {
			_runtime.diverge();
		}
		_lev_div1 = _lev_6;
		div1 = _val_6;
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
			_val_5 = document['createElement']('div');
			_lev_5 = _iflow_sig._updtLab(_val_5, _lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
		} else {
			_lev_5 = _pc;
			_val_5 = document;
			while (!_runtime.hasOwnProperty(_val_5, 'createElement')) {
				_lev_5 = _runtime.lat.lub(_lev_5, _val_5._lev_proto, _val_5._lev_struct);
				_val_5 = _val_5._proto;
			}
			if (_val_5) {
				_lev_5 = _runtime.lat.lub(_lev_5, _val_5[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_5, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'div', _lev_ctxt);
			_val_5 = _ret._val;
			_lev_5 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div2)) {
			_runtime.diverge();
		}
		_lev_div2 = _lev_5;
		div2 = _val_5;
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
			_val_4 = document['createElement']('div');
			_lev_4 = _iflow_sig._updtLab(_val_4, _lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
		} else {
			_lev_4 = _pc;
			_val_4 = document;
			while (!_runtime.hasOwnProperty(_val_4, 'createElement')) {
				_lev_4 = _runtime.lat.lub(_lev_4, _val_4._lev_proto, _val_4._lev_struct);
				_val_4 = _val_4._proto;
			}
			if (_val_4) {
				_lev_4 = _runtime.lat.lub(_lev_4, _val_4[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_4, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'div', _lev_ctxt);
			_val_4 = _ret._val;
			_lev_4 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div3)) {
			_runtime.diverge();
		}
		_lev_div3 = _lev_4;
		div3 = _val_4;
		_lev_ctxt = _runtime.lat.lub(_lev_div1, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(div1, 'appendChild', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, div1, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			_val_3 = div1['appendChild'](div2);
			_lev_3 = _iflow_sig._updtLab(_val_3, _lev_ctxt, div1, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
		} else {
			_lev_3 = _pc;
			_val_3 = div1;
			while (!_runtime.hasOwnProperty(_val_3, 'appendChild')) {
				_lev_3 = _runtime.lat.lub(_lev_3, _val_3._lev_proto, _val_3._lev_struct);
				_val_3 = _val_3._proto;
			}
			if (_val_3) {
				_lev_3 = _runtime.lat.lub(_lev_3, _val_3[_runtime.shadow('appendChild')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_3, div1['appendChild']._lev_fscope);
			_ret = div1['appendChild'](_lev_ctxt, div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			_val_3 = _ret._val;
			_lev_3 = _ret._lev;
		}
		if ( typeof h === 'object')
			_runtime.diverge('Illegal Coercion');
		_pc_holder_1 = _pc;
		_pc = _runtime.lat.lub(_lev_h, _pc);
		if (h) {
			_lev_ctxt = _runtime.lat.lub(_lev_div3, _pc);
			_iflow_sig = _runtime.api_register.getIFlowSig(div3, 'appendChild', 'method_call');
			if (_iflow_sig) {
				_iflow_sig._enforce(_lev_ctxt, div3, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
				_val_2 = div3['appendChild'](div2);
				_lev_2 = _iflow_sig._updtLab(_val_2, _lev_ctxt, div3, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			} else {
				_lev_2 = _pc;
				_val_2 = div3;
				while (!_runtime.hasOwnProperty(_val_2, 'appendChild')) {
					_lev_2 = _runtime.lat.lub(_lev_2, _val_2._lev_proto, _val_2._lev_struct);
					_val_2 = _val_2._proto;
				}
				if (_val_2) {
					_lev_2 = _runtime.lat.lub(_lev_2, _val_2[_runtime.shadow('appendChild')]);
				}
				_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_2, div3['appendChild']._lev_fscope);
				_ret = div3['appendChild'](_lev_ctxt, div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
				_val_2 = _ret._val;
				_lev_2 = _ret._lev;
			}
		}
		_pc = _pc_holder_1;
		_lev_ctxt = _runtime.lat.lub(_lev_div1, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(div1, 'childNodes', 'prop_lookup');
		if (_iflow_sig) {
			_iflow_sig._enforce(div1, 'childNodes', _lev_ctxt);
			_val_1 = div1['childNodes'];
			_lev_1 = _iflow_sig._updtLab(_val_1, div1, 'childNodes', _lev_ctxt);
		} else {
			_lev_1 = _pc;
			_val_1 = div1;
			while (!_runtime.hasOwnProperty(_val_1, 'childNodes')) {
				_lev_1 = _runtime.lat.lub(_lev_1, _val_1._lev_proto, _val_1._lev_struct);
				_val_1 = _val_1._proto;
			}
			if (_val_1) {
				_lev_1 = _runtime.lat.lub(_lev_1, _val_1[_runtime.shadow('childNodes')]);
			}
			_val_1 = div1['childNodes'];
			_lev_1 = _runtime.lat.lub(_lev_ctxt, _lev_1);
		}
		_lev_nvar_0 = _lev_1;
		nvar_0 = _val_1;
		_lev_ctxt = _runtime.lat.lub(_lev_nvar_0, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(nvar_0, 'length', 'prop_lookup');
		if (_iflow_sig) {
			_iflow_sig._enforce(nvar_0, 'length', _lev_ctxt);
			_val_0 = nvar_0['length'];
			_lev_0 = _iflow_sig._updtLab(_val_0, nvar_0, 'length', _lev_ctxt);
		} else {
			_lev_0 = _pc;
			_val_0 = nvar_0;
			while (!_runtime.hasOwnProperty(_val_0, 'length')) {
				_lev_0 = _runtime.lat.lub(_lev_0, _val_0._lev_proto, _val_0._lev_struct);
				_val_0 = _val_0._proto;
			}
			if (_val_0) {
				_lev_0 = _runtime.lat.lub(_lev_0, _val_0[_runtime.shadow('length')]);
			}
			_val_0 = nvar_0['length'];
			_lev_0 = _runtime.lat.lub(_lev_ctxt, _lev_0);
		}
		if (!_runtime.lat.leq(_pc, _lev_l)) {
			_runtime.diverge();
		}
		_lev_l = _lev_0;
		l = _val_0;
	});



    /*
     * var div1, div2, div3, h, l; 
     * h = 1; 
     * upgVar(h,  '2'); 
     * div1 = document.createElement('div');
     * div2 = document.createElement('div');
     * div3 = document.createElement('div');
     * div1.appendChild(div2);
     * upgStruct(div1, '2'); 
     * upgStruct(div3, '2'); 
     * div2.upgTreeLevel('2');
     * if (h) {
     *    div3.appendChild(div2);
     * }
     * l = div1.childNodes.length;
     */
	test('createElement + appendChild - 1', function() {
		var _lev_this, _val_7, _lev_7, _val_6, _lev_6, _val_5, _lev_5, _val_4, _lev_4, _val_3, _lev_3, _val_2, _lev_2, _pc_holder_1, _val_1, _lev_1, _val_0, _lev_0, _pc, _lev_ctxt, _ret;
		var div1, div2, div3, h, l, nvar_1, _lev_div1, _lev_div2, _lev_div3, _lev_h, _lev_l, _lev_nvar_1;
		_pc = _runtime.lat.bot;
		_lev_this = _pc;
		_lev_div1 = _pc;
		_lev_div2 = _pc;
		_lev_div3 = _pc;
		_lev_h = _pc;
		_lev_l = _pc;
		_lev_nvar_1 = _pc;
		_runtime.createShadowWindowProperties();
		if (!_runtime.lat.leq(_pc, _lev_h)) {
			_runtime.diverge();
		}
		_lev_h = _pc;
		h = 1;
		if (!_runtime.lat.leq(_pc, _lev_h)) {
			_runtime.diverge();
		}
		_lev_h = _runtime.lat.lub(_lev_h, '2');
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
			_val_7 = document['createElement']('div');
			_lev_7 = _iflow_sig._updtLab(_val_7, _lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
		} else {
			_lev_7 = _pc;
			_val_7 = document;
			while (!_runtime.hasOwnProperty(_val_7, 'createElement')) {
				_lev_7 = _runtime.lat.lub(_lev_7, _val_7._lev_proto, _val_7._lev_struct);
				_val_7 = _val_7._proto;
			}
			if (_val_7) {
				_lev_7 = _runtime.lat.lub(_lev_7, _val_7[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_7, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'div', _lev_ctxt);
			_val_7 = _ret._val;
			_lev_7 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div1)) {
			_runtime.diverge();
		}
		_lev_div1 = _lev_7;
		div1 = _val_7;
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
			_val_6 = document['createElement']('div');
			_lev_6 = _iflow_sig._updtLab(_val_6, _lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
		} else {
			_lev_6 = _pc;
			_val_6 = document;
			while (!_runtime.hasOwnProperty(_val_6, 'createElement')) {
				_lev_6 = _runtime.lat.lub(_lev_6, _val_6._lev_proto, _val_6._lev_struct);
				_val_6 = _val_6._proto;
			}
			if (_val_6) {
				_lev_6 = _runtime.lat.lub(_lev_6, _val_6[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_6, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'div', _lev_ctxt);
			_val_6 = _ret._val;
			_lev_6 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div2)) {
			_runtime.diverge();
		}
		_lev_div2 = _lev_6;
		div2 = _val_6;
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
			_val_5 = document['createElement']('div');
			_lev_5 = _iflow_sig._updtLab(_val_5, _lev_ctxt, document, 'createElement', 'div', _lev_ctxt);
		} else {
			_lev_5 = _pc;
			_val_5 = document;
			while (!_runtime.hasOwnProperty(_val_5, 'createElement')) {
				_lev_5 = _runtime.lat.lub(_lev_5, _val_5._lev_proto, _val_5._lev_struct);
				_val_5 = _val_5._proto;
			}
			if (_val_5) {
				_lev_5 = _runtime.lat.lub(_lev_5, _val_5[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_5, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'div', _lev_ctxt);
			_val_5 = _ret._val;
			_lev_5 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div3)) {
			_runtime.diverge();
		}
		_lev_div3 = _lev_5;
		div3 = _val_5;
		_lev_ctxt = _runtime.lat.lub(_lev_div1, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(div1, 'appendChild', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, div1, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			_val_4 = div1['appendChild'](div2);
			_lev_4 = _iflow_sig._updtLab(_val_4, _lev_ctxt, div1, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
		} else {
			_lev_4 = _pc;
			_val_4 = div1;
			while (!_runtime.hasOwnProperty(_val_4, 'appendChild')) {
				_lev_4 = _runtime.lat.lub(_lev_4, _val_4._lev_proto, _val_4._lev_struct);
				_val_4 = _val_4._proto;
			}
			if (_val_4) {
				_lev_4 = _runtime.lat.lub(_lev_4, _val_4[_runtime.shadow('appendChild')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_4, div1['appendChild']._lev_fscope);
			_ret = div1['appendChild'](_lev_ctxt, div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			_val_4 = _ret._val;
			_lev_4 = _ret._lev;
		}
		if (!_runtime.lat.leq(_runtime.lat.lub(_lev_div1, _pc), div1._lev_struct)) {
			_runtime.diverge();
		}
		div1._lev_struct = _runtime.lat.lub(div1._lev_struct, '2');
		if (!_runtime.lat.leq(_runtime.lat.lub(_lev_div3, _pc), div3._lev_struct)) {
			_runtime.diverge();
		}
		div3._lev_struct = _runtime.lat.lub(div3._lev_struct, '2');
		_lev_ctxt = _runtime.lat.lub(_lev_div2, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(div2, 'upgTreeLevel', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, div2, 'upgTreeLevel', '2', _lev_ctxt);
			_val_3 = div2['upgTreeLevel']('2');
			_lev_3 = _iflow_sig._updtLab(_val_3, _lev_ctxt, div2, 'upgTreeLevel', '2', _lev_ctxt);
		} else {
			_lev_3 = _pc;
			_val_3 = div2;
			while (!_runtime.hasOwnProperty(_val_3, 'upgTreeLevel')) {
				_lev_3 = _runtime.lat.lub(_lev_3, _val_3._lev_proto, _val_3._lev_struct);
				_val_3 = _val_3._proto;
			}
			if (_val_3) {
				_lev_3 = _runtime.lat.lub(_lev_3, _val_3[_runtime.shadow('upgTreeLevel')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_3, div2['upgTreeLevel']._lev_fscope);
			_ret = div2['upgTreeLevel'](_lev_ctxt, '2', _lev_ctxt);
			_val_3 = _ret._val;
			_lev_3 = _ret._lev;
		}
		if ( typeof h === 'object')
			_runtime.diverge('Illegal Coercion');
		_pc_holder_1 = _pc;
		_pc = _runtime.lat.lub(_lev_h, _pc);
		if (h) {
			_lev_ctxt = _runtime.lat.lub(_lev_div3, _pc);
			_iflow_sig = _runtime.api_register.getIFlowSig(div3, 'appendChild', 'method_call');
			if (_iflow_sig) {
				_iflow_sig._enforce(_lev_ctxt, div3, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
				_val_2 = div3['appendChild'](div2);
				_lev_2 = _iflow_sig._updtLab(_val_2, _lev_ctxt, div3, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			} else {
				_lev_2 = _pc;
				_val_2 = div3;
				while (!_runtime.hasOwnProperty(_val_2, 'appendChild')) {
					_lev_2 = _runtime.lat.lub(_lev_2, _val_2._lev_proto, _val_2._lev_struct);
					_val_2 = _val_2._proto;
				}
				if (_val_2) {
					_lev_2 = _runtime.lat.lub(_lev_2, _val_2[_runtime.shadow('appendChild')]);
				}
				_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_2, div3['appendChild']._lev_fscope);
				_ret = div3['appendChild'](_lev_ctxt, div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
				_val_2 = _ret._val;
				_lev_2 = _ret._lev;
			}
		}
		_pc = _pc_holder_1;
		_lev_ctxt = _runtime.lat.lub(_lev_div1, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(div1, 'childNodes', 'prop_lookup');
		if (_iflow_sig) {
			_iflow_sig._enforce(div1, 'childNodes', _lev_ctxt);
			_val_1 = div1['childNodes'];
			_lev_1 = _iflow_sig._updtLab(_val_1, div1, 'childNodes', _lev_ctxt);
		} else {
			_lev_1 = _pc;
			_val_1 = div1;
			while (!_runtime.hasOwnProperty(_val_1, 'childNodes')) {
				_lev_1 = _runtime.lat.lub(_lev_1, _val_1._lev_proto, _val_1._lev_struct);
				_val_1 = _val_1._proto;
			}
			if (_val_1) {
				_lev_1 = _runtime.lat.lub(_lev_1, _val_1[_runtime.shadow('childNodes')]);
			}
			_val_1 = div1['childNodes'];
			_lev_1 = _runtime.lat.lub(_lev_ctxt, _lev_1);
		}
		_lev_nvar_1 = _lev_1;
		nvar_1 = _val_1;
		_lev_ctxt = _runtime.lat.lub(_lev_nvar_1, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(nvar_1, 'length', 'prop_lookup');
		if (_iflow_sig) {
			_iflow_sig._enforce(nvar_1, 'length', _lev_ctxt);
			_val_0 = nvar_1['length'];
			_lev_0 = _iflow_sig._updtLab(_val_0, nvar_1, 'length', _lev_ctxt);
		} else {
			_lev_0 = _pc;
			_val_0 = nvar_1;
			while (!_runtime.hasOwnProperty(_val_0, 'length')) {
				_lev_0 = _runtime.lat.lub(_lev_0, _val_0._lev_proto, _val_0._lev_struct);
				_val_0 = _val_0._proto;
			}
			if (_val_0) {
				_lev_0 = _runtime.lat.lub(_lev_0, _val_0[_runtime.shadow('length')]);
			}
			_val_0 = nvar_1['length'];
			_lev_0 = _runtime.lat.lub(_lev_ctxt, _lev_0);
		}
		if (!_runtime.lat.leq(_pc, _lev_l)) {
			_runtime.diverge();
		}
		_lev_l = _lev_0;
		l = _val_0;
	});


}); 