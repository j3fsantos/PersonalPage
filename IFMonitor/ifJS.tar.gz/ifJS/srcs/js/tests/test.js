$(function() {

   module('Testing a single example');

/*

*/




	test('createElement + appendChild + getElementsById - 1', function() {
		var _lev_this, _val_57, _lev_57, _val_56, _lev_56, _val_55, _lev_55, _val_54, _lev_54, _val_53, _lev_53, _val_52, _lev_52, _val_51, _lev_51, _val_50, _lev_50, _val_49, _lev_49, _val_48, _lev_48, _val_47, _lev_47, _pc_holder_5, _val_46, _lev_46, _pc, _lev_ctxt, _ret;
		var div1, div2, div3, divs, h, l, nvar_8, nvar_9, _lev_div1, _lev_div2, _lev_div3, _lev_divs, _lev_h, _lev_l, _lev_nvar_8, _lev_nvar_9;
		_pc = _runtime.lat.bot;
		_lev_this = _pc;
		_lev_div1 = _pc;
		_lev_div2 = _pc;
		_lev_div3 = _pc;
		_lev_divs = _pc;
		_lev_h = _pc;
		_lev_l = _pc;
		_lev_nvar_8 = _pc;
		_lev_nvar_9 = _pc;
		_runtime.createShadowWindowProperties();
		_iflow_sig = _runtime.api_register.getIFlowSig(confirm, null, 'function_call');
		_lev_ctxt = _pc;
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, confirm, 'Do you want to execute the if-then branch?', _lev_ctxt);
			_val_57 = confirm('Do you want to execute the if-then branch?');
			_lev_57 = _iflow_sig._updtLab(_val_57, _lev_ctxt, confirm, 'Do you want to execute the if-then branch?', _lev_ctxt);
		} else {
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, confirm._lev_fscope, _lev_confirm);
			_ret = confirm(_lev_ctxt, 'Do you want to execute the if-then branch?', _lev_ctxt);
			_val_57 = _ret._val;
			_lev_57 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_h)) {
			_runtime.diverge();
		}
		_lev_h = _lev_57;
		h = _val_57;
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'DIV', _lev_ctxt);
			_val_56 = document['createElement']('DIV');
			_lev_56 = _iflow_sig._updtLab(_val_56, _lev_ctxt, document, 'createElement', 'DIV', _lev_ctxt);
		} else {
			_lev_56 = _pc;
			_val_56 = document;
			while (!_runtime.hasOwnProperty(_val_56, 'createElement')) {
				_lev_56 = _runtime.lat.lub(_lev_56, _val_56._lev_proto, _val_56._lev_struct);
				_val_56 = _val_56._proto;
			}
			if (_val_56) {
				_lev_56 = _runtime.lat.lub(_lev_56, _val_56[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_56, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'DIV', _lev_ctxt);
			_val_56 = _ret._val;
			_lev_56 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div1)) {
			_runtime.diverge();
		}
		_lev_div1 = _lev_56;
		div1 = _val_56;
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'DIV', _lev_ctxt);
			_val_55 = document['createElement']('DIV');
			_lev_55 = _iflow_sig._updtLab(_val_55, _lev_ctxt, document, 'createElement', 'DIV', _lev_ctxt);
		} else {
			_lev_55 = _pc;
			_val_55 = document;
			while (!_runtime.hasOwnProperty(_val_55, 'createElement')) {
				_lev_55 = _runtime.lat.lub(_lev_55, _val_55._lev_proto, _val_55._lev_struct);
				_val_55 = _val_55._proto;
			}
			if (_val_55) {
				_lev_55 = _runtime.lat.lub(_lev_55, _val_55[_runtime.shadow('createElement')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_55, document['createElement']._lev_fscope);
			_ret = document['createElement'](_lev_ctxt, 'DIV', _lev_ctxt);
			_val_55 = _ret._val;
			_lev_55 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div2)) {
			_runtime.diverge();
		}
		_lev_div2 = _lev_55;
		div2 = _val_55;
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'body', 'prop_lookup');
		if (_iflow_sig) {
			_iflow_sig._enforce(document, 'body', _lev_ctxt);
			_val_54 = document['body'];
			_lev_54 = _iflow_sig._updtLab(_val_54, document, 'body', _lev_ctxt);
		} else {
			_lev_54 = _pc;
			_val_54 = document;
			while (!_runtime.hasOwnProperty(_val_54, 'body')) {
				_lev_54 = _runtime.lat.lub(_lev_54, _val_54._lev_proto, _val_54._lev_struct);
				_val_54 = _val_54._proto;
			}
			if (_val_54) {
				_lev_54 = _runtime.lat.lub(_lev_54, _val_54[_runtime.shadow('body')]);
			}
			_val_54 = document['body'];
			_lev_54 = _runtime.lat.lub(_lev_ctxt, _lev_54);
		}
		_lev_nvar_8 = _lev_54;
		nvar_8 = _val_54;
		_lev_ctxt = _runtime.lat.lub(_lev_nvar_8, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(nvar_8, 'appendChild', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, nvar_8, 'appendChild', div1, _runtime.lat.lub(_lev_div1, _lev_ctxt));
			_val_53 = nvar_8['appendChild'](div1);
			_lev_53 = _iflow_sig._updtLab(_val_53, _lev_ctxt, nvar_8, 'appendChild', div1, _runtime.lat.lub(_lev_div1, _lev_ctxt));
		} else {
			_lev_53 = _pc;
			_val_53 = nvar_8;
			while (!_runtime.hasOwnProperty(_val_53, 'appendChild')) {
				_lev_53 = _runtime.lat.lub(_lev_53, _val_53._lev_proto, _val_53._lev_struct);
				_val_53 = _val_53._proto;
			}
			if (_val_53) {
				_lev_53 = _runtime.lat.lub(_lev_53, _val_53[_runtime.shadow('appendChild')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_53, nvar_8['appendChild']._lev_fscope);
			_ret = nvar_8['appendChild'](_lev_ctxt, div1, _runtime.lat.lub(_lev_div1, _lev_ctxt));
			_val_53 = _ret._val;
			_lev_53 = _ret._lev;
		}
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'body', 'prop_lookup');
		if (_iflow_sig) {
			_iflow_sig._enforce(document, 'body', _lev_ctxt);
			_val_52 = document['body'];
			_lev_52 = _iflow_sig._updtLab(_val_52, document, 'body', _lev_ctxt);
		} else {
			_lev_52 = _pc;
			_val_52 = document;
			while (!_runtime.hasOwnProperty(_val_52, 'body')) {
				_lev_52 = _runtime.lat.lub(_lev_52, _val_52._lev_proto, _val_52._lev_struct);
				_val_52 = _val_52._proto;
			}
			if (_val_52) {
				_lev_52 = _runtime.lat.lub(_lev_52, _val_52[_runtime.shadow('body')]);
			}
			_val_52 = document['body'];
			_lev_52 = _runtime.lat.lub(_lev_ctxt, _lev_52);
		}
		_lev_nvar_9 = _lev_52;
		nvar_9 = _val_52;
		_lev_ctxt = _runtime.lat.lub(_lev_nvar_9, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(nvar_9, 'appendChild', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, nvar_9, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			_val_51 = nvar_9['appendChild'](div2);
			_lev_51 = _iflow_sig._updtLab(_val_51, _lev_ctxt, nvar_9, 'appendChild', div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
		} else {
			_lev_51 = _pc;
			_val_51 = nvar_9;
			while (!_runtime.hasOwnProperty(_val_51, 'appendChild')) {
				_lev_51 = _runtime.lat.lub(_lev_51, _val_51._lev_proto, _val_51._lev_struct);
				_val_51 = _val_51._proto;
			}
			if (_val_51) {
				_lev_51 = _runtime.lat.lub(_lev_51, _val_51[_runtime.shadow('appendChild')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_51, nvar_9['appendChild']._lev_fscope);
			_ret = nvar_9['appendChild'](_lev_ctxt, div2, _runtime.lat.lub(_lev_div2, _lev_ctxt));
			_val_51 = _ret._val;
			_lev_51 = _ret._lev;
		}
		_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(document, 'getElementsByTagName', 'method_call');
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, document, 'getElementsByTagName', 'DIV', _lev_ctxt);
			_val_50 = document['getElementsByTagName']('DIV');
			_lev_50 = _iflow_sig._updtLab(_val_50, _lev_ctxt, document, 'getElementsByTagName', 'DIV', _lev_ctxt);
		} else {
			_lev_50 = _pc;
			_val_50 = document;
			while (!_runtime.hasOwnProperty(_val_50, 'getElementsByTagName')) {
				_lev_50 = _runtime.lat.lub(_lev_50, _val_50._lev_proto, _val_50._lev_struct);
				_val_50 = _val_50._proto;
			}
			if (_val_50) {
				_lev_50 = _runtime.lat.lub(_lev_50, _val_50[_runtime.shadow('getElementsByTagName')]);
			}
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_50, document['getElementsByTagName']._lev_fscope);
			_ret = document['getElementsByTagName'](_lev_ctxt, 'DIV', _lev_ctxt);
			_val_50 = _ret._val;
			_lev_50 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_divs)) {
			_runtime.diverge();
		}
		_lev_divs = _lev_50;
		divs = _val_50;
		if (!_runtime.lat.leq(_runtime.lat.lub(_lev_div1, _pc), div1._lev_struct)) {
			_runtime.diverge();
		}
		div1._lev_struct = _runtime.lat.lub(div1._lev_struct, '5');
		_iflow_sig = _runtime.api_register.getIFlowSig(upgGlobalTagLevel, null, 'function_call');
		_lev_ctxt = _pc;
		if (_iflow_sig) {
			_iflow_sig._enforce(_lev_ctxt, upgGlobalTagLevel, 'DIV', _lev_ctxt, '5', _lev_ctxt);
			_val_49 = upgGlobalTagLevel('DIV', '5');
			_lev_49 = _iflow_sig._updtLab(_val_49, _lev_ctxt, upgGlobalTagLevel, 'DIV', _lev_ctxt, '5', _lev_ctxt);
		} else {
			_lev_ctxt = _runtime.lat.lub(_lev_ctxt, upgGlobalTagLevel._lev_fscope, _lev_upgGlobalTagLevel);
			_ret = upgGlobalTagLevel(_lev_ctxt, 'DIV', _lev_ctxt, '5', _lev_ctxt);
			_val_49 = _ret._val;
			_lev_49 = _ret._lev;
		}
		if (!_runtime.lat.leq(_pc, _lev_div3)) {
			_runtime.diverge();
		}
		_lev_div3 = _runtime.lat.lub(_lev_div3, '5');
		if ( typeof h === 'object')
			_runtime.diverge('Illegal Coercion');
		_pc_holder_5 = _pc;
		_pc = _runtime.lat.lub(_lev_h, _pc);
		if (h) {
			_lev_ctxt = _runtime.lat.lub(_lev_document, _pc);
			_iflow_sig = _runtime.api_register.getIFlowSig(document, 'createElement', 'method_call');
			if (_iflow_sig) {
				_iflow_sig._enforce(_lev_ctxt, document, 'createElement', 'DIV', _lev_ctxt);
				_val_48 = document['createElement']('DIV');
				_lev_48 = _iflow_sig._updtLab(_val_48, _lev_ctxt, document, 'createElement', 'DIV', _lev_ctxt);
			} else {
				_lev_48 = _pc;
				_val_48 = document;
				while (!_runtime.hasOwnProperty(_val_48, 'createElement')) {
					_lev_48 = _runtime.lat.lub(_lev_48, _val_48._lev_proto, _val_48._lev_struct);
					_val_48 = _val_48._proto;
				}
				if (_val_48) {
					_lev_48 = _runtime.lat.lub(_lev_48, _val_48[_runtime.shadow('createElement')]);
				}
				_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_48, document['createElement']._lev_fscope);
				_ret = document['createElement'](_lev_ctxt, 'DIV', _lev_ctxt);
				_val_48 = _ret._val;
				_lev_48 = _ret._lev;
			}
			if (!_runtime.lat.leq(_pc, _lev_div3)) {
				_runtime.diverge();
			}
			_lev_div3 = _lev_48;
			div3 = _val_48;
			_lev_ctxt = _runtime.lat.lub(_lev_div1, _pc);
			_iflow_sig = _runtime.api_register.getIFlowSig(div1, 'appendChild', 'method_call');
			if (_iflow_sig) {
				_iflow_sig._enforce(_lev_ctxt, div1, 'appendChild', div3, _runtime.lat.lub(_lev_div3, _lev_ctxt));
				_val_47 = div1['appendChild'](div3);
				_lev_47 = _iflow_sig._updtLab(_val_47, _lev_ctxt, div1, 'appendChild', div3, _runtime.lat.lub(_lev_div3, _lev_ctxt));
			} else {
				_lev_47 = _pc;
				_val_47 = div1;
				while (!_runtime.hasOwnProperty(_val_47, 'appendChild')) {
					_lev_47 = _runtime.lat.lub(_lev_47, _val_47._lev_proto, _val_47._lev_struct);
					_val_47 = _val_47._proto;
				}
				if (_val_47) {
					_lev_47 = _runtime.lat.lub(_lev_47, _val_47[_runtime.shadow('appendChild')]);
				}
				_lev_ctxt = _runtime.lat.lub(_lev_ctxt, _lev_47, div1['appendChild']._lev_fscope);
				_ret = div1['appendChild'](_lev_ctxt, div3, _runtime.lat.lub(_lev_div3, _lev_ctxt));
				_val_47 = _ret._val;
				_lev_47 = _ret._lev;
			}
		}
		_pc = _pc_holder_5;
		_lev_ctxt = _runtime.lat.lub(_lev_divs, _pc);
		_iflow_sig = _runtime.api_register.getIFlowSig(divs, 1, 'prop_lookup');
		if (_iflow_sig) {
			_iflow_sig._enforce(divs, 1, _lev_ctxt);
			_val_46 = divs[1];
			_lev_46 = _iflow_sig._updtLab(_val_46, divs, 1, _lev_ctxt);
		} else {
			_lev_46 = _pc;
			_val_46 = divs;
			while (!_runtime.hasOwnProperty(_val_46, 1)) {
				_lev_46 = _runtime.lat.lub(_lev_46, _val_46._lev_proto, _val_46._lev_struct);
				_val_46 = _val_46._proto;
			}
			if (_val_46) {
				_lev_46 = _runtime.lat.lub(_lev_46, _val_46[_runtime.shadow(1)]);
			}
			_val_46 = divs[1];
			_lev_46 = _runtime.lat.lub(_lev_ctxt, _lev_46);
		}
		if (!_runtime.lat.leq(_pc, _lev_l)) {
			_runtime.diverge();
		}
		_lev_l = _lev_46;
		l = _val_46;
	});











});
