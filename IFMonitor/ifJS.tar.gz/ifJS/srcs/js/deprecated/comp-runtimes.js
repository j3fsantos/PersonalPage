/*
 * 1)   enforce(level_1, level_2) 
 * 2)   setVarLev(var, level, _lab)
 * 3)   setPropLev(obj, prop,level)
 * 4)   setStructLev(obj, level)
 * 5)   getVarLev(var, labeling)
 * 6)   getPropLev(obj, prop)
 * 7)   getStructLev(obj)
 * 8)   initObject(proto, level)
 * 9)   initLab(old_labeling, array_args_strings, array_args_levels, declared_vars_arr, init_pc_level)
 */


(function(exports) {
	
	var consts = {
	   LAB_PROP_IDENT: '_lab',
	   STRUCT_PROP_IDENT: '_struct',   
	   LEV_PROP_IDENT: '_lev', 
	   IS_ARGUMENTS_ARRAY: '_is_arguments_array'
	}; 
	
		
   function randomizeRuntimeConsts() {
      var n;
      n = Math.random() * 1000;
      n = Math.floor(n);
      for (var prop in exports.consts) {
         exports.consts[prop] = exports.consts[prop] + '_' + n + '_';
      }
      return n;
   }
	
	
	function create(proto) {
		var F;  
		if(proto) {
			F = function () {}; 
		   F.prototype = proto; 
		   return new F();
		} else {
			return {}; 
		}
	}
	
	
   //  enforce(level_1, level_2)
   function enforce(level_1, level_2, ignore_enforcement) {
   	if (ignore_enforcement) {
   		return true; 
   	}
   	
      if (this.lat.leq(level_1, level_2)) {
         return true;
      } else {
         throw new Error('IFlow Exception');
      }
   }


   // unrestrainUpgds(_lab, 'x', 'y', 'z') 
   function unrestrainUpgds() {
   	var lab; 
   	lab = arguments[0]; 
   	
   	if (!lab.unrestrained) {
   		lab.unrestrained = {}; 
   	}
   	
   	for (i = 1, len = arguments.length; i < len; i++) {
   		lab.unrestrained[arguments[i]] = true; 
   	}
   }
   
      
   //_runtime.forbidVarUpg(_lab, 'x')
   function forbidVarUpg(lab, var_name) {
   	if (!exports.internalHasOwnProperty(lab, 'forbidUpgds')) {
   		lab.forbidUpgds = {}; 
   		lab.forbidUpgds.toString = false;
   		lab.forbidUpgds.hasOwnProperty = false;  
   	}
   	lab.forbidUpgds[var_name] = true; 
   }
   
   
   //_runtime.forbidPropUpg(_lab, 'o', p)
   function forbidPropUpg(obj, prop) {
   	var lab; 
   	
   	if (!exports.internalHasOwnProperty(obj, consts.LAB_PROP_IDENT)) {
   		lab = {};
   		lab[consts.LAB_PROP_IDENT] = null;
         lab.forbidUpgds = {};
         obj[consts.LAB_PROP_IDENT] = lab;
   	}
   	
   	forbidVarUpg(obj[consts.LAB_PROP_IDENT], prop);  
   }
   
   
   //setVarLev(var, level, _lab)
   function setVarLev(variable, level, labeling) {
      if (!labeling) {
         return false;
      }

      if (exports.internalHasOwnProperty(labeling, variable)) {
         labeling[variable] = level;
         return true;
      }

      return setVarLev(variable, level, labeling._lab);
   }


   // setPropLev(obj, prop,level, is_strict)
   function setPropLev(obj, prop, level, is_strict) {
      if (!exports.internalHasOwnProperty(obj, consts.LAB_PROP_IDENT)) {
         if(exports.internalHasOwnProperty(obj, consts.LEV_PROP_IDENT)) {
         	obj[consts.LEV_PROP_IDENT] = this.lat.lub(obj[consts.LEV_PROP_IDENT], level); 
         	return true; 
         } else {
         	obj[consts.LAB_PROP_IDENT] = initLabSimple([], this.lat.bot);
         }
      }
      
      if(is_strict && (!this.lat.eq(obj[consts.LAB_PROP_IDENT][prop], level))) {
         throw new Error('Property Not Upgradable!')
      } else {
      	if (obj[consts.IS_ARGUMENTS_ARRAY]) {
            prop = obj[consts.LAB_PROP_IDENT].argsList[prop];
         } 
         
         obj[consts.LAB_PROP_IDENT][prop] = level;	
      }
      
      return true; 
   }


   // setStructLev(obj, level)
   // '_struct' -> property that holds the struct security level
   function setStructLev(obj, level) {
      return setPropLev(obj, consts.STRUCT_PROP_IDENT, level);
   }


   //  getVarLev(var, labeling)
   function getVarLev(variable, labeling) {
      if (!labeling) {
         return this.lat.bot;
      }

      if (exports.internalHasOwnProperty(labeling, variable)) {
         return labeling[variable];
      }

      return getVarLev(variable, labeling[consts.LAB_PROP_IDENT]);
   }


   // getPropLev(obj, prop)
   function getPropLev(obj, prop) {
      if (!exports.internalHasOwnProperty(obj, consts.LAB_PROP_IDENT)) {
      	if(exports.internalHasOwnProperty(obj, consts.LEV_PROP_IDENT)) {
      		return obj[consts.LEV_PROP_IDENT]; 
      	} else {
			   return this.lat.bot;      		
      	}
      }
      
      if (obj[consts.IS_ARGUMENTS_ARRAY]) {
         prop = obj[consts.LAB_PROP_IDENT].argsList[prop];
      } 
      
      if ((obj instanceof Array) && (prop === 'length')) {
      	return getVarLev(consts.STRUCT_PROP_IDENT, obj[consts.LAB_PROP_IDENT]);
      } else {
         return getVarLev(prop, obj[consts.LAB_PROP_IDENT]);	
      }
   };


   // getStructLev(obj)
   function getStructLev(obj) {
      return getPropLev(obj, consts.STRUCT_PROP_IDENT);
   };

   // initObject(object, level, proto)
   function initObject(proto, level) {
      var lab, object, old_lab;
      lab = {};
      lab[consts.STRUCT_PROP_IDENT] = level; 
      if (proto && ((typeof proto) === 'object') && (exports.internalHasOwnProperty(proto, consts.LAB_PROP_IDENT))) {
         lab[consts.LAB_PROP_IDENT] = proto[consts.LAB_PROP_IDENT];
      } else {
         lab[consts.LAB_PROP_IDENT] = null;
      }
      object = create(proto);
      Object.defineProperty(object, consts.LAB_PROP_IDENT, {
      	enumerable: false, 
      	value: lab
      });
      lab.forbidUpgds = {};  
      lab.forbidUpgds.toString = false;
      lab.forbidUpgds.hasOwnProperty = false;
      lab.forbidUpgds.valueOf = false;   
      return object; 
   };

	// initArray(level)
   function initArray(level) {
      var lab, arr;
      lab = {};
      lab[consts.STRUCT_PROP_IDENT] = level;
      lab[consts.LAB_PROP_IDENT] = null;
      
      lab.forbidUpgds = {};  
      lab.forbidUpgds.toString = false;
      lab.forbidUpgds.hasOwnProperty = false;
      lab.forbidUpgds.valueOf = false;
      
      arr = []; 
      arr.lab = lab; 
      return arr; 
   };

   // initLabArgs(old_labeling, array_args_strings, array_args_levels, declared_vars_arr, init_pc_level)
   function initLabArgs(old_labeling, array_args_strings, array_args_levels, array_declared_vars_strings, init_pc_level) {
      var i, len, lab; 
      lab = { };
      lab[consts.LAB_PROP_IDENT] = old_labeling; 
      
      for (i = 0, len = array_args_strings.length; i < len; i++) {
         lab[array_args_strings[i]] = array_args_levels[i]; 
      } 
      
      for (i = 0, len = array_declared_vars_strings.length; i < len; i++) {
         lab[array_declared_vars_strings[i]] = init_pc_level; 
      } 
      
      lab.argsList = array_args_strings;
      lab.unrestrained = {}; 
      lab.forbidUpgds = {};
      lab.forbidUpgds.toString = false;
      lab.forbidUpgds.hasOwnProperty = false;  
      return lab; 
   }
   
   // initLabSimple(declared_vars_arr, init_pc_level)
   function initLabSimple(array_declared_vars_strings, init_pc_level) {
   	var i, len, lab; 
      lab = { };
      lab[consts.LAB_PROP_IDENT] = null; 
      
      for (i = 0, len = array_declared_vars_strings.length; i < len; i++) {
         lab[array_declared_vars_strings[i]] = init_pc_level; 
      } 
      
      lab.unrestrained = {}; 
      lab.forbidUpgds = {}; 
      lab.forbidUpgds.toString = false;
      lab.forbidUpgds.hasOwnProperty = false; 
      return lab;
   }
   
   // initLab(...)   
   function initLab() {
      if (arguments[0] && (exports.internalHasOwnProperty(arguments[0], consts.LAB_PROP_IDENT))) {
         return initLabArgs.apply(null, arguments);
      } else {
         return initLabSimple.apply(null, arguments); 	
      }
   }
   
   function isValidPropertyAccess(obj, prop) {
   	var aux = (typeof prop); 
   	if ((aux === 'string') || (aux === 'number')) {
   		return; 
   	}
   	throw new Error('Illegal Implicit Type Coercion'); 
   }

   function isValidOpInvocation(op, arg1, arg2) {
   	var type_arg_1, type_arg_2; 
   	
   	if ((type_arg_1 = (typeof arg1)) === 'object') {
   		throw new Error('Illegal Implicit Type Coercion');
   	}
   	 
   	if (arg2) {
   		if ((type_arg_2 = (typeof arg2)) === 'object') {
   		    throw new Error('Illegal Implicit Type Coercion');
   	   } else {
   	 	   if ((type_arg_1 != type_arg_2)) {
   	 	 	   throw new Error('Illegal Implicit Type Coercion');
   	      }
   	   }
      }
   }
   
   (function () {
      var obj, hasOwnProp, internalHasOwnProperty; 
      obj = {};
      hasOwnProp = obj.hasOwnProperty;  
      internalHasOwnProperty = function (obj, prop) {
         return hasOwnProp.call(obj, prop);	
      };   	
      exports.internalHasOwnProperty = internalHasOwnProperty;  
   })();
   
   
   (function(){
   	var getUrlLevel, url_levels; 
   	
   	url_levels = {}; 
   	getUrlLevel = function(url) {
   		url = parseUri(url).host; 
   		if(url in url_levels) {
   			return url_levels[url];
   		}
   		return exports.lat.bot; 
   	};
   	
      setUrlLevel = function(url, level) {
      	url = parseUri(url).host;
      	url_levels[url] = level; 
      };
      
      clearUrlsTable = function () {
      	url_levels = {};
      };
      
   	exports.getUrlLevel = getUrlLevel; 
   	exports.setUrlLevel = setUrlLevel;
   	exports.clearUrlsTable = clearUrlsTable;  
   })();
   
   function clearBrowsingData() {
   	this.clearUrlsTable(); 
   	delete document[consts.LAB_PROP_IDENT];  
   	delete window[consts.LAB_PROP_IDENT]; 
   }
   
   function internalCall() {
   	var args, 
   	    i, 
   	    len; 
   	args = []; 
   	for(i=2, len=arguments.length; i<len; i++) {
   		args[i-2] = arguments[i]; 
   	}
   	return arguments[1].apply(arguments[0], args); 
   };

   function parseUri(str) {
      var o = parseUri.options, m = o.parser[o.strictMode ? "strict" : "loose"].exec(str), uri = {}, i = 14;

      while (i--)
      uri[o.key[i]] = m[i] || "";

      uri[o.q.name] = {};
      uri[o.key[12]].replace(o.q.parser, function($0, $1, $2) {
         if ($1)
            uri[o.q.name][$1] = $2;
      });

      return uri;
   };

   parseUri.options = {
      strictMode : false,
      key : ["source", "protocol", "authority", "userInfo", "user", "password", "host", "port", "relative", "path", "directory", "file", "query", "anchor"],
      q : {
         name : "queryKey",
         parser : /(?:^|&)([^&=]*)=?([^&]*)/g
      },
      parser : {
         strict : /^(?:([^:\/?#]+):)?(?:\/\/((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?))?((((?:[^?#\/]*\/)*)([^?#]*))(?:\?([^#]*))?(?:#(.*))?)/,
         loose : /^(?:(?![^:@]+:[^:@\/]*@)([^:\/?#.]+):)?(?:\/\/)?((?:(([^:@]*)(?::([^:@]*))?)?@)?([^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/
      }
   }; 
      
      
   // Exporting variables... 
   exports.enforce = enforce; 
   exports.setVarLev = setVarLev; 
   exports.setPropLev = setPropLev;
   exports.setStructLev = setStructLev;  
   exports.getVarLev = getVarLev; 
   exports.getPropLev = getPropLev; 
   exports.getStructLev = getStructLev; 
   exports.initObject = initObject;
   exports.initArray = initArray;  
   exports.initLab = initLab; 
   exports.isValidPropertyAccess = isValidPropertyAccess; 
   exports.isValidOpInvocation = isValidOpInvocation; 
   exports.consts = consts; 
   exports.call = internalCall; 
   exports.unrestrainUpgds = unrestrainUpgds; 
   exports.forbidPropUpg = forbidPropUpg; 
   exports.forbidVarUpg = forbidVarUpg; 
   exports.clearBrowsingData = clearBrowsingData; 
   
})(_runtime);









