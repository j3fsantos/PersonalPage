/*
 * Eval
 *   - the expression being evaluated must not declare any new variables 
 *     in the current scope
 */

(function (exports) {
   
   enforceFun = function () { }; 
   
   computeRetLevelFun = function (str, str_level_arr, ctxt_level, ret_val) {
   	if (ret_val) {
   		return ret_val[comp.identifiers.consts.LEV_PROP_IDENT]; 
   	} else {
   		return ctxt_level; 
   	} 
   };
   
   computeRetValFun = function (str, str_level_arr, ctxt_level, ret_val) {
   	if (ret_val) {
   		return ret_val[comp.identifiers.consts.VAL_PROP_IDENT]; 
   	} else {
   		return undefined; 
   	} 
   }; 
   
   updtArgsLevelsFun = function () {};
   
   processArg = function (str) {
   	var call_expr,
   	    compiled_args,
   	    compiled_assignment_aux,
   	    compiled_stmt_1,
   	    compiled_stmt_1_str, 
   	    compiled_stmt_2_str, 
   	    compiled_fun_expr,  
   	    fun_expr;
   	
   	// function(argsLevels, pc) { C[str] }     
      str = '(function () { ' + str + '})()';
      call_expr = window.util.parseExpr(str); 
      fun_expr = call_expr.callee; 
      window.util.addReturnToLastExpressionStatement(fun_expr); 
      compiled_fun_expr = comp.computeNewFunctionLiteral(fun_expr);
      
      // _aux_1 = function(argsLevels, pc) { C[str] }
      compiled_args = [
          window.esprima.delegate.createArrayExpression([]), 
          window.esprima.delegate.createIdentifier('_pc')
      ];
      compiled_assignment_aux = window.esprima.delegate.createAssignmentExpression(
         '=', 
         window.esprima.delegate.createIdentifier(comp.identifiers.getAuxIdentifierStr(3)), 
         compiled_fun_expr); 
      compiled_stmt_1 = window.esprima.delegate.createExpressionStatement(compiled_assignment_aux); 
      compiled_stmt_1_str = window.util.printStmtST(compiled_stmt_1);
      
      // _aux_3._pc = _pc; _aux_3._lab = _lab; _aux_3([], _pc);
      compiled_stmt_2_str = '{0}.{1} = {2}; {0}.{3} = {4}; {0}([], {2});';
      compiled_stmt_2_str = $.validator.format(compiled_stmt_2_str,
         comp.identifiers.getAuxIdentifierStr(3), 
         comp.identifiers.consts.PC_PROP_IDENT, 
         comp.identifiers.consts.PC_IDENT,
         comp.identifiers.consts.LAB_PROP_IDENT,
         comp.identifiers.consts.LAB_IDENT); 
       
      return compiled_stmt_1_str + compiled_stmt_2_str;  
   };
   
   exports.setInterfaceFunctions(eval, enforceFun, computeRetLevelFun, updtArgsLevelsFun, computeRetValFun, processArg);
})(_runtime);


/*
 * setTimeOut
 */
(function (exports) {
   enforceFun = function () { }; 
   
   computeRetLevelFun = function (str, str_level_arr, ctxt_level, ret_val) {
   	if (ret_val) {
   		return ret_val[comp.identifiers.consts.LEV_PROP_IDENT]; 
   	} else {
   		return ctxt_level; 
   	} 
   };
   
   computeRetValFun = function (str, str_level_arr, ctxt_level, ret_val) {
   	if (ret_val) {
   		return ret_val[comp.identifiers.consts.LEV_PROP_IDENT]; 
   	} else {
   		return ret_val; 
   	} 
   }; 
   
   updtArgsLevelsFun = function () {};
   
   processArg = function(str, index, evaluator) {
   	if (index === 1) {
   		return processArg_1(str, evaluator);  
   	} else { 
   		return str;
   	}
   }
   
   processArg_1 = function(str, evaluator) {
      var body_stmts, 
          call_expr, 
          compiled_assignment_aux, 
          compiled_stmt_1, 
          compiled_stmt_1_str, 
          compiled_stmt_2_str, 
          compiled_fun_expr, 
          fun_expr, 
          try_catch_stmt;
     
      if (typeof str === 'function') {
      	return str; 
      }
 
      // function(argsLevels, pc) { try { C[str] } catch(e) {...}  }
      str = '(function () {  ' + str + ' })()';
      call_expr = window.util.parseExpr(str);
      fun_expr = call_expr.callee;
      compiled_fun_expr = comp.computeNewFunctionLiteral(fun_expr);
      // $(\'#prog_output\').css(\'background-color\', \'red\');
     
      str = 'window.jQuery(window.document.getElementById(\'prog_output\')).css(\'background-color\', \'red\');';
      str = 'try { } catch(e) { ' + str + ' }'
      try_catch_stmt = window.util.parseStmt(str);
      body_stmts = compiled_fun_expr.body.body; 
      try_catch_stmt.block.body = body_stmts; 
      compiled_fun_expr.body.body = [ try_catch_stmt ];

      // _aux_3 = function(argsLevels, pc) { C[str] }
      compiled_assignment_aux = window.esprima.delegate.createAssignmentExpression('=', 
         window.esprima.delegate.createIdentifier(comp.identifiers.getAuxIdentifierStr(3)), 
         compiled_fun_expr);
      compiled_stmt_1 = window.esprima.delegate.createExpressionStatement(compiled_assignment_aux);
      compiled_stmt_1_str = window.util.printStmtST(compiled_stmt_1);

      //  _aux_3._pc = _pc; _aux_3._lab = _lab; _aux_3;
      compiled_stmt_2_str = '{0}.{1} = {2}; {0}.{3} = {4}; {0}';
      compiled_stmt_2_str = $.validator.format(compiled_stmt_2_str,
         comp.identifiers.getAuxIdentifierStr(3), 
         comp.identifiers.consts.PC_PROP_IDENT, 
         comp.identifiers.consts.PC_IDENT,
         comp.identifiers.consts.LAB_PROP_IDENT,
         comp.identifiers.consts.LAB_IDENT); 
       
      return evaluator(compiled_stmt_1_str + compiled_stmt_2_str);
   }; 
   
   exports.setInterfaceFunctions(setTimeout, enforceFun, computeRetLevelFun, updtArgsLevelsFun, computeRetValFun, processArg);
})(_runtime); 


/*
 * alert
 */
(function (exports) {
   enforceFun = function (str, args_levels, ctxt_level) { 
   	if (exports.lat.lub(ctxt_level, args_levels[0]) != exports.lat.bot) {
   		throw new Error('IFlow Exception'); 
   	}
   }; 
   
   computeRetLevelFun = function (arg, arg_level_arr, ctxt_level, ret_val) {
   	return ctxt_level;
   };
   
   computeRetValFun = function (arg, arg_level_arr, ctxt_level, ret_val) {
   	return ret_val;  
   }; 
   
   updtArgsLevelsFun = function () {};
   
   processArg = function(str, index, evaluator) {
   	return str; 
   }
   
   exports.setInterfaceFunctions(alert, enforceFun, computeRetLevelFun, updtArgsLevelsFun, computeRetValFun, processArg);
})(_runtime); 


/*
 * confirm
 */
(function (exports) {
   enforceFun = function () { }; 
   
   computeRetLevelFun = function (arg, arg_level_arr, ctxt_level, ret_val) {
   	return exports.lat.top;
   };
   
   computeRetValFun = function (arg, arg_level_arr, ctxt_level, ret_val) {
   	return ret_val;  
   }; 
   
   updtArgsLevelsFun = function () {};
   
   processArg = function(str, index, evaluator) {
   	return str; 
   };
   
   exports.setInterfaceFunctions(confirm, enforceFun, computeRetLevelFun, updtArgsLevelsFun, computeRetValFun, processArg);
})(_runtime); 


/*
 * object.toString() 
 * enforce_fun, compute_ret_level_fun, updt_args_levels_fun, process_ret_val_fun
 * 
 */
(function (exports) {
   
   function enforceFun() {  
   }; 
   
	function processReturnValue(obj, arg, args_levels, ctx_level, ret_obj) {
		return ret_obj; 
	};
   
   function computeReturnLevel(obj, arg, args_levels, ctx_level) {
   	return exports.lat.lub(args_levels[0], ctx_level);
   };
   
   function updateArgsLevels(obj, arg, args_levels, ctx_level) { 
   };
   
   exports.setInterfaceMethod(document, 'toString', enforceFun, computeReturnLevel, updateArgsLevels, processReturnValue);    
})(_runtime);


/*
 * document.createTextNode(str) 
 * enforce_fun, compute_ret_level_fun, updt_args_levels_fun, process_ret_val_fun
 * 
 */
(function (exports) {
   
   function enforceFun(obj, arg, args_levels, ctxt_level) {
   	if ((typeof arg) !== 'string') {
   		throw new Error('IFlow Exception'); 
   	} 
   	return true;  
   }; 
   
	function processReturnValue(obj, arg, args_levels, ctx_level, ret_obj) {
		ret_obj[exports.consts.LEV_PROP_IDENT] = exports.lat.lub(args_levels[0], args_levels[1], ctx_level);
		return ret_obj;
	};
   
   function computeReturnLevel(obj, arg, args_levels, ctx_level) {
   	return exports.lat.lub(args_levels[0], args_levels[1], ctx_level);
   };
   
   function updateArgsLevels(obj, arg, args_levels, ctx_level) { 
   };
   
   exports.setInterfaceMethod(document, 'createTextNode', enforceFun, computeReturnLevel, updateArgsLevels, processReturnValue);    
})(_runtime);


/*
 * document.createElement('div') 
 * 
 * enforce_fun, compute_ret_level_fun, updt_args_levels_fun, process_ret_val_fun
 */
(function (exports) {
   
   function enforceFun(obj, arg, args_levels, ctxt_level) {
   	if ((typeof arg) !== 'string') {
   		throw new Error('IFlow Exception'); 
   	} 
   	return true; 
   }; 
   
	function processReturnValue(obj, arg, args_levels, ctxt_level, ret_obj) {
		ret_obj[exports.consts.LEV_PROP_IDENT] = exports.lat.lub(args_levels[0], args_levels[1], ctxt_level);
		return ret_obj;
	};
   
   function computeReturnLevel(obj, arg, args_levels, ctxt_level) {
   	return exports.lat.lub(args_levels[0], args_levels[1], ctxt_level);
   };
   
   function updateArgsLevels(obj, arg, args_levels, ctxt_level) { 
   };
   
   exports.setInterfaceMethod(document, 'createElement', enforceFun, computeReturnLevel, updateArgsLevels, processReturnValue);   
})(_runtime);


/*
 * element.appendChild(child_node) 
 * 
 * enforce_fun, compute_ret_level_fun, updt_args_levels_fun, process_ret_val_fun
 */
(function (exports) {
   
   function enforceFun(obj, arg, args_levels, ctxt_level) { 
   	if (!(exports.lat.leq(exports.lat.lub(args_levels[0], args_levels[1], ctxt_level), obj[exports.consts.LEV_PROP_IDENT]))) {
   		throw new Error('IFlow Error'); 
   	}
   }
   
	function processReturnValue(obj, arg, args_levels, ctxt_level, ret_obj) {
		//ret_obj[exports.consts.LEV_PROP_IDENT] = exports.lat.lub(args_levels[0], args_levels[1], ctxt_level);
		return ret_obj;
	}
   
   function computeReturnLevel(obj, arg, args_levels, ctxt_level) {
   	return exports.lat.lub(args_levels[0], args_levels[1], ctxt_level);
   }
   
   function updateArgsLevels(obj, arg, args_levels, ctxt_level) {
   }
   
   exports.setInterfaceMethod(document.createElement('div'), 'appendChild', enforceFun, computeReturnLevel, updateArgsLevels, processReturnValue);   
})(_runtime);


/*
 * new XMLHttpRequest(); 
 * { enforce_fun: f1, compute_new_obj_level_fun, updt_args_levels_fun: f3}
 */
(function (exports) {
   
   function enforceFun() { }; 
   
   function computeNewObjLevel(args_levels, ctxt_level, new_obj) {
   	new_obj[exports.consts.LEV_PROP_IDENT] = ctxt_level; 
   	return ctxt_level;
   };
   
   function updateArgsLevels() { };
   
   exports.setInterfaceConstructor('XMLHttpRequest', enforceFun, computeNewObjLevel, updateArgsLevels);   
})(_runtime);


/*
 * xhr.open(http_method, url); 
 * enforce_fun, compute_ret_level_fun, updt_args_levels_fun, process_ret_val_fun
 */
(function (exports) {

   function enforceFun(obj, arg_1, arg_2, args_levels, ctxt_level) {
   	var level_1, level_2;
      level_1 = exports.lat.lub(args_levels[0], args_levels[1], args_levels[2], ctxt_level);
      level_2 = exports.getUrlLevel(arg_2);
      if (!exports.lat.leq(level_1, level_2)) {
         throw new Error('IFlow Exception - Illegal invocation of XHR open() method');
      }
   }

   function processReturnValue(obj, arg_1, arg_2, args_levels, ctxt_level, ret_obj) {
      var level_1, level_2;
      level_1 = exports.lat.lub(args_levels[0], args_levels[1], args_levels[2], ctxt_level, obj[exports.consts.LEV_PROP_IDENT]);
      level_2 = exports.getUrlLevel(arg_2);

      obj[exports.consts.LEV_PROP_IDENT] = level_2;
      return ret_obj;
   }

   function computeReturnLevel(obj, arg_1, arg_2, args_levels, ctxt_level) {
      return ctxt_level;
   }

   function updateArgsLevels() { };

   exports.setInterfaceMethod(new XMLHttpRequest(), 'open', enforceFun, computeReturnLevel, updateArgsLevels, processReturnValue);   
})(_runtime);


/*
 * xhr.send(data); 
 * enforce_fun, compute_ret_level_fun, updt_args_levels_fun, process_ret_val_fun
 */
(function(exports) {

   
   function enforceFun(obj, arg, args_levels, ctxt_level) {
   	if (arguments.length !== 4) {
   		return true; 
   	}
   	if (!(exports.lat.leq(exports.lat.lub(args_levels[0], args_levels[1], ctxt_level), obj[exports.consts.LEV_PROP_IDENT]))) {
         throw new Error('IFlow Exception - Illegal invocation of XHR send() method');
      }
   }


   function processReturnValue(obj, arg, args_levels, ctxt_level, ret_obj) {
      return ret_obj;
   }

   function computeReturnLevel(obj, arg, args_levels, ctxt_level, ret_obj) {
      return ctxt_level;
   }

   function updateArgsLevels() {
   }

   exports.setInterfaceMethod(new XMLHttpRequest(), 'send', enforceFun, computeReturnLevel, updateArgsLevels, processReturnValue);
})(_runtime);
