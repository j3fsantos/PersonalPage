/*
 * 1)   enforce(level_1, level_2) 
 * 2)   setVarLev(var, level, _lab)
 * 3)   setPropLev(obj, prop,level)
 * 4)   setStructLev(obj, level)
 * 5)   getVarLev(var, labeling)
 * 6)   getPropLev(obj, prop)
 * 7)   getStructLev(obj)
 * 8)   initObject(proto, level)
 * 9)   initLab(old_labeling, array_args_strings, array_args_levels, declared_vars_arr, init_pc_level)
 */


(function(exports) {
	
	var consts = {
	   LAB_PROP_IDENT: '_lab',
	   STRUCT_PROP_IDENT: '_struct',   
	   LEV_PROP_IDENT: '_lev'
	}; 
	
		
   function randomizeRuntimeConsts() {
      var n;
      n = Math.random() * 1000;
      n = Math.floor(n);
      for (var prop in exports.consts) {
         exports.consts[prop] = exports.consts[prop] + '_' + n + '_';
      }
      return n;
   }
	
	
	function create(proto) {
		var F;  
		if(proto) {
			F = function () {}; 
		   F.prototype = proto; 
		   return new F();
		} else {
			return {}; 
		}
	}
	
	
   //  enforce(level_1, level_2)
   function enforce(level_1, level_2) {
      if (this.lat.leq(level_1, level_2)) {
         return true;
      } else {
         throw new Error('IFlow Exception');
      }
   }


   //setVarLev(var, level, _lab)
   function setVarLev(variable, level, labeling) {
      if (!labeling) {
         return false;
      }

      if (labeling.hasOwnProperty(variable)) {
         labeling[variable] = level;
         return true;
      }

      return setVarLev(variable, level, labeling._lab);
   }


   // setPropLev(obj, prop,level)
   function setPropLev(obj, prop, level) {
      if (!obj.hasOwnProperty(consts.LAB_PROP_IDENT)) {
         if(obj.hasOwnProperty(consts.LEV_PROP_IDENT)) {
         	obj[consts.LEV_PROP_IDENT] = this.lat.lub(obj[consts.LEV_PROP_IDENT], level); 
         	return true; 
         } else {
         	obj[consts.LAB_PROP_IDENT] = initLabSimple([], this.lat.bot);
         }
      }
      obj[consts.LAB_PROP_IDENT][prop] = level;
      return true; 
   }


   // setStructLev(obj, level)
   // '_struct' -> property that holds the struct security level
   function setStructLev(obj, level) {
      return setPropLev(obj, consts.STRUCT_PROP_IDENT, level);
   }


   //  getVarLev(var, labeling)
   function getVarLev(variable, labeling) {
      if (!labeling) {
         return this.lat.bot;
      }

      if (labeling.hasOwnProperty(variable)) {
         return labeling[variable];
      }

      return getVarLev(variable, labeling[consts.LAB_PROP_IDENT]);
   }


   // getPropLev(obj, prop)
   function getPropLev(obj, prop) {
      if (!obj.hasOwnProperty(consts.LAB_PROP_IDENT)) {
      	if(obj.hasOwnProperty(consts.LEV_PROP_IDENT)) {
      		return obj[consts.LEV_PROP_IDENT]; 
      	} else {
			   return this.lat.bot;      		
      	}
      }

      return getVarLev(prop, obj[consts.LAB_PROP_IDENT]);
   }


   // getStructLev(obj)
   function getStructLev(obj) {
      return getPropLev(obj, consts.STRUCT_PROP_IDENT);
   }

   // initObject(object, level, proto)
   function initObject(proto, level) {
      var lab, object, old_lab;
      lab = {};
      lab[consts.STRUCT_PROP_IDENT] = level; 
      if (proto && ((typeof proto) === 'object') && (proto.hasOwnProperty(consts.LAB_PROP_IDENT))) {
         lab[consts.LAB_PROP_IDENT] = proto[consts.LAB_PROP_IDENT];
      } else {
         lab[consts.LAB_PROP_IDENT] = null;
      }
      object = create(proto);
      object[consts.LAB_PROP_IDENT] = lab; 
      return object; 
   }

   // initLabArgs(old_labeling, array_args_strings, array_args_levels, declared_vars_arr, init_pc_level)
   function initLabArgs(old_labeling, array_args_strings, array_args_levels, array_declared_vars_strings, init_pc_level) {
      var i, len, lab; 
      lab = { };
      lab[consts.LAB_PROP_IDENT] = old_labeling; 
      
      for (i = 0, len = array_args_strings.length; i < len; i++) {
         lab[array_args_strings[i]] = array_args_levels[i]; 
      } 
      
      for (i = 0, len = array_declared_vars_strings.length; i < len; i++) {
         lab[array_declared_vars_strings[i]] = init_pc_level; 
      } 
      
      return lab; 
   }
   
   // initLabSimple(declared_vars_arr, init_pc_level)
   function initLabSimple(array_declared_vars_strings, init_pc_level) {
   	var i, len, lab; 
      lab = { };
      lab[consts.LAB_PROP_IDENT] = null; 
      
      for (i = 0, len = array_declared_vars_strings.length; i < len; i++) {
         lab[array_declared_vars_strings[i]] = init_pc_level; 
      } 
      
      return lab;
   }
   
   // initLab(...)   
   function initLab() {
      if (arguments[0] && (arguments[0].hasOwnProperty(consts.LAB_PROP_IDENT))) {
         return initLabArgs.apply(null, arguments);
      } else {
         return initLabSimple.apply(null, arguments); 	
      }
   }
   
   function isValidPropertyAccess(obj, prop) {
   	var aux = (typeof prop); 
   	if ((aux === 'string') || (aux === 'number')) {
   		return; 
   	}
   	throw new Error('Illegal Implicit Type Coercion'); 
   }

   function isValidOpInvocation(op, arg1, arg2) {
   	var type_arg_1, type_arg_2; 
   	
   	if ((type_arg_1 = (typeof arg1)) === 'object') {
   		throw new Error('Illegal Implicit Type Coercion');
   	}
   	 
   	if (arg2) {
   		if ((type_arg_2 = (typeof arg2)) === 'object') {
   		    throw new Error('Illegal Implicit Type Coercion');
   	   } else {
   	 	   if ((type_arg_1 != type_arg_2)) {
   	 	 	   throw new Error('Illegal Implicit Type Coercion');
   	      }
   	   }
      }
   }
   
   (function () {
      var obj, hasOwnProp, internalHasOwnProperty; 
      obj = {};
      hasOwnProp = obj.hasOwnProperty;  
      internalHasOwnProperty = function (obj, prop) {
         return hasOwnProp.call(obj, prop)	
      }   	
      exports.internalHasOwnProperty = internalHasOwnProperty;  
   })();
   
   
   (function(){
   	var getUrlLevel, url_levels; 
   	
   	url_levels = {}; 
   	getUrlLevel = function(url) {
   		if(url in url_levels) {
   			return url_levels[url];
   		}
   		return exports.lat.bot; 
   	};
   	
      setUrlLevel = function(url, level) {
      	url_levels[url] = level; 
      };
      
   	exports.getUrlLevel = getUrlLevel; 
   	exports.setUrlLevel = setUrlLevel; 
   })();
   
   function internalCall() {
   	var args, 
   	    i, 
   	    len; 
   	args = []; 
   	for(i=2, len=arguments.length; i<len; i++) {
   		args[i-2] = arguments[i]; 
   	}
   	return arguments[1].apply(arguments[0], args); 
   };

   // Exporting variables... 
   exports.enforce = enforce; 
   exports.setVarLev = setVarLev; 
   exports.setPropLev = setPropLev;
   exports.setStructLev = setStructLev;  
   exports.getVarLev = getVarLev; 
   exports.getPropLev = getPropLev; 
   exports.getStructLev = getStructLev; 
   exports.initObject = initObject; 
   exports.initLab = initLab; 
   exports.isValidPropertyAccess = isValidPropertyAccess; 
   exports.isValidOpInvocation = isValidOpInvocation; 
   exports.consts = consts; 
   exports.call = internalCall; 
   
})(_runtime);









