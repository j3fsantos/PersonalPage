/*
 * 1) lat
 * 2) lat.lub(level_1, ..., level_2)
 * 3) lat.leq(level_1, level_2)
 * 4) lat.bot
 * 5) lat.top 
 */

(function(exports) {
   lat = {};

   lat.top = 5;
   lat.bot = 0;

   lat.parseString = function(level_str) {
      return parseInt(level_str, 10);
   };

   lat.processArgs = function(args) {
      var i, len;
      for ( i = 0, len = args.length; i < len; i++) {
         if (( typeof args[i]) === 'string') {
            args[i] = this.parseString(args[i]);
         }
      }
   };

   lat.lub = function() {
      var i, len, lub = this._bot;
      this.processArgs(arguments);
      for ( i = 0, len = arguments.length; i < len; i++) {
         if (!this.leqInternal(arguments[i], lub)) {
            lub = arguments[i]
         }
      }
      return lub;
   };

   lat.leqInternal = function(lev_1, lev_2) {
      return lev_1 <= lev_2;
   };

   lat.leq = function(lev_1, lev_2) {
      this.processArgs(arguments);
      return this.leqInternal(lev_1, lev_2);
   }; 
   
   exports.lat = lat; 
})(_runtime);
