/*
 *  getEnforceFun(f)
 *  getComputeRetLevelFun(f) 
 *  getUpdtArgsLevelsFun(f)
 *  setInterfaceFunctions(f, enforce_fun, compute_ret_level_fun, updt_args_levels_fun)
 */

(function (exports) {
	
	function getExternalObjectType(obj) {
		return 'object';
	}
	
	/*
	 *   Table: keys - function name
	 *   Values { enforce_fun: f1, compute_ret_level_fun: f2, compute_ret_val_fun: f3, updt_args_levels_fun: f4}
	 */
	var external_interface_functions_table = {}; 
	
   function getEnforceFun(f) {
      return external_interface_functions_table[window.util.getFunctionName(f)].enforce_fun; 	
   };
   
   function getComputeRetLevelFun(f) {
      return external_interface_functions_table[window.util.getFunctionName(f)].compute_ret_level_fun; 	
   };
   
   function getComputeRetValFun(f) {
      return external_interface_functions_table[window.util.getFunctionName(f)].compute_ret_val_fun; 	
   };
   
   function getUpdtArgsLevelsFun(f) {
      return external_interface_functions_table[window.util.getFunctionName(f)].updt_args_levels_fun; 	
   };
   
   function getProcessArg(f) {
   	return external_interface_functions_table[window.util.getFunctionName(f)].process_arg;
   };
   
   function setInterfaceFunctions(f, enforce_fun, compute_ret_level_fun, updt_args_levels_fun, compute_ret_val_fun, process_arg) {
   	external_interface_functions_table[window.util.getFunctionName(f)] = {
   		enforce_fun: enforce_fun, 
   		compute_ret_level_fun: compute_ret_level_fun, 
   		updt_args_levels_fun: updt_args_levels_fun, 
   		compute_ret_val_fun: compute_ret_val_fun, 
   		process_arg: process_arg
   	}; 
   };  
   
   exports.getEnforceFun = getEnforceFun; 
   exports.getComputeRetLevelFun = getComputeRetLevelFun; 
   exports.getUpdtArgsLevelsFun = getUpdtArgsLevelsFun; 
   exports.getComputeRetValFun = getComputeRetValFun;
   exports.getProcessArg = getProcessArg; 
   exports.setInterfaceFunctions = setInterfaceFunctions; 
   
   /*
    * Methods
    * 
    */
   
   /*
    *   Table - 
    *     keys - dom types
    *     values - table:  
    *                keys - methodNames
    *                values - { enforce_fun: f1, compute_ret_level_fun: f2, updt_args_levels_fun: f3, process_ret_val_fun: f4}
    */
   var external_interface_methods_table = {}; 
     
   function getEnforceMethod(obj, method_name) {
   	var type = getExternalObjectType(obj);
      return external_interface_methods_table[type][method_name].enforce_fun; 	
   }
   
   function getComputeRetLevelMethod(obj, method_name) {
   	var type = getExternalObjectType(obj);
      return external_interface_methods_table[type][method_name].compute_ret_level_fun;
   }
   
   function getUpdtArgsLevelsMethod(obj, method_name) {
   	var type = getExternalObjectType(obj);
      return external_interface_methods_table[type][method_name].updt_args_levels_fun;
   }
   
   function getProcessRetValue(obj, method_name) {
   	var type = getExternalObjectType(obj);
      return external_interface_methods_table[type][method_name].process_ret_val_fun;
   }
   
   function setInterfaceMethod(obj, method_name, enforce_fun, compute_ret_level_fun, updt_args_levels_fun, process_ret_val_fun) {
   	var type = getExternalObjectType(obj);
   	
   	if (!external_interface_methods_table[type]) {
   		external_interface_methods_table[type] = {}; 
   	}
   	
   	external_interface_methods_table[type][method_name] = {
   	    enforce_fun: enforce_fun, 
   	    compute_ret_level_fun: compute_ret_level_fun, 
   	    updt_args_levels_fun: updt_args_levels_fun, 
   	    process_ret_val_fun: process_ret_val_fun
   	}
   }
   
   exports.getEnforceMethod = getEnforceMethod; 
   exports.getComputeRetLevelMethod = getComputeRetLevelMethod; 
   exports.getUpdtArgsLevelsMethod = getUpdtArgsLevelsMethod;
   exports.getProcessRetValue = getProcessRetValue; 
   exports.setInterfaceMethod = setInterfaceMethod; 
   
   
   /*
    * Constructor
    * 
    */
   
   /*
    *   Table - 
    *     keys - constructor names
    *     values - { enforce_fun: f1, compute_new_obj_level_fun, updt_args_levels_fun: f3}
    */
   var external_interface_constructors_table = {}; 
   
   function getEnforceConstructor(constructor) {
   	var constructor_name; 
   	constructor_name = window.util.getFunctionName(constructor); 
      return external_interface_constructors_table[constructor_name].enforce_fun; 	
   }
   
   function getNewObjLevel(constructor) {
   	var constructor_name; 
   	constructor_name = window.util.getFunctionName(constructor);
      return external_interface_constructors_table[constructor_name].compute_new_obj_level_fun;
   }
   
   function getUpdtArgsLevelsConstructor(constructor) {
   	var constructor_name; 
   	constructor_name = window.util.getFunctionName(constructor);
      return external_interface_constructors_table[constructor_name].updt_args_levels_fun;
   }
   
   function setInterfaceConstructor(constructor_name, enforce_fun, compute_new_obj_level_fun, updt_args_levels_fun) {
   	external_interface_constructors_table[constructor_name] = {
   	    enforce_fun: enforce_fun, 
   	    compute_new_obj_level_fun: compute_new_obj_level_fun, 
   	    updt_args_levels_fun: updt_args_levels_fun
   	}
   }
   
   exports.getEnforceConstructor = getEnforceConstructor; 
   exports.getNewObjLevel = getNewObjLevel; 
   exports.getUpdtArgsLevelsConstructor = getUpdtArgsLevelsConstructor;
   exports.setInterfaceConstructor = setInterfaceConstructor; 
})(_runtime); 


