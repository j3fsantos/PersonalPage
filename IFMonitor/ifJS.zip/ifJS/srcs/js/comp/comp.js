var comp = {}; 


comp.compile = function(st){
	if(!st) return st; 
	switch(st.type)	{
		case 'Program': 
		   return this.compileProgram(st); 
		case 'ExpressionStatement': 
		   return this.compileExprStmt(st); 
		case 'CallExpression':
		   return this.compileCallExpr(st); 
		case 'NewExpression': 
		   return this.compileConstructorCallExpr(st);  
		case 'ObjectExpression': 
		   return this.compileObjectExpr(st); 
		case 'AssignmentExpression': 
		   return  this.compileAssignmentExpr(st); 
		case 'Literal': 
		   return this.compileLiteralExpr(st); 
		case 'Identifier': 
		   return this.compileIdentifierExpr(st);   
		case 'MemberExpression': 
		   return this.compilePropLookUpExpr(st); 
		case 'ThisExpression': 
		   return this.compileThisExpr(st);
		case 'BinaryExpression': 
		   return this.compileBinOpExpr(st); 
		case 'UnaryExpression': 
		   return this.compileUnOpExpr(st);
	   case 'BlockStatement':
	      return this.compileBlockStmt(st);
	   case 'WhileStatement': 
	      return this.compileWhileStmt(st); 
	   case 'IfStatement':
	      return this.compileIfStmt(st);  
	   case 'ReturnStatement': 
	      return this.compileReturnStmt(st);  
	   case 'FunctionExpression': 
	      return this.compileFunctionLiteralExpr(st); 
	   case 'VariableDeclaration': 
	      return null;  
	   case 'ArrayExpression': 
	      return this.compileArrayExpr(st);
		default:  
		   if (!st.type) {
		   	throw new Error('Syntax Error - Illegal Program')
		   } else {
		   	throw new Error('Construct ' + st.type + ' is not supported yet')
		   }   
	}
};


/*
 * ********************************************************************************************************************
 * BASE CASES
 **********************************************************************************************************************
 */


comp.compileIdentifierExpr = function (ident_st) {
	return $.extend(true, {}, ident_st);
};


comp.compileLiteralExpr = function (literal_st) {
	return $.extend(true, {}, literal_st);
};


comp.compileThisExpr = function (this_st) {
  	return $.extend(true, {}, this_st);
}; 


/*
 * Original Code: op ê
 * Compiled code: 
 *    _runtime.isValidOpInvocation(op, ê);
 *    _val_i = op ê; 
 *    _lev_i = C_l[op ê]; 
 * Runtimes: isValidOpInvocation 
 */
comp.compileUnOpExpr = function (un_op_expr) {
	var assignment_aux, 
	    assignment_stmt_1, 
	    assignment_stmt_2, 
	    assignment_stmt_3,
	    call_expr_aux, 
	    val_lev_vars; 
	
	val_lev_vars = this.identifiers.getFreeValLevVars();
	
	// _runtime.isValidOpInvocation(op, ê);
	call_expr_aux = window.esprima.delegate.createCallExpression(
		window.esprima.delegate.createIdentifier(this.identifiers.getRuntimeMemberExprStr('isValidOpInvocation')), 
		[
		   window.esprima.delegate.createLiteral2(un_op_expr.operator), 
		   un_op_expr.argument
		]
	);
	assignment_stmt_1 = window.esprima.delegate.createExpressionStatement(call_expr_aux);
	
	// _val_i = ê_1 op ê_2;
	assignment_aux = window.esprima.delegate.createAssignmentExpression(
		'=',
		window.esprima.delegate.createIdentifier(val_lev_vars.val_var),  
		$.extend(true, {}, un_op_expr)); 
	assignment_stmt_2 = window.esprima.delegate.createExpressionStatement(assignment_aux);
	
	// _lev_i = C_l[ê_1 op ê_2]; 
	assignment_aux = window.esprima.delegate.createAssignmentExpression(
		'=',
		window.esprima.delegate.createIdentifier(val_lev_vars.lev_var),  
		this.level.compile(un_op_expr.argument, true));
   assignment_stmt_3 = window.esprima.delegate.createExpressionStatement(assignment_aux);
	
	return {
   	compiled_stmts: [ 
   	   assignment_stmt_1, 
   	   assignment_stmt_2, 
   	   assignment_stmt_3
   	], 
   	new_vars: [
   	   val_lev_vars
   	]
   };
}; 


/*
 * Original Code: ê_1 op ê_2
 * Compiled code: 
 *    _runtime.isValidOpInvocation(op, ê_1, ê_2);
 *    _val_i = ê_1 op ê_2; 
 *    _lev_i = C_l[ê_1 op ê_2];
 * Runtimes: isValidOpInvocation
 */
comp.compileBinOpExpr = function (bin_op_expr) {
	var assignment_aux, 
	    assignment_stmt_1, 
	    assignment_stmt_2, 
	    assignment_stmt_3,
	    call_expr_aux, 
	    val_lev_vars; 
	    
	val_lev_vars = this.identifiers.getFreeValLevVars();
	
	// _isValidOpInvocation(op, ê_1, ê_2);
	call_expr_aux = window.esprima.delegate.createCallExpression(
		window.esprima.delegate.createIdentifier(this.identifiers.getRuntimeMemberExprStr('isValidOpInvocation')), 
		[
		   window.esprima.delegate.createLiteral2(bin_op_expr.operator), 
		   bin_op_expr.left, 
		   bin_op_expr.right
		]
	);
	assignment_stmt_1 = window.esprima.delegate.createExpressionStatement(call_expr_aux);
	
	// _val_i = ê_1 op ê_2;
	assignment_aux = window.esprima.delegate.createAssignmentExpression(
		'=',
		window.esprima.delegate.createIdentifier(val_lev_vars.val_var),  
		$.extend(true, {}, bin_op_expr)); 
	assignment_stmt_2 = window.esprima.delegate.createExpressionStatement(assignment_aux);
	
	// _lev_i = C_l[ê_1 op ê_2]; 
	assignment_aux = window.esprima.delegate.createAssignmentExpression(
		'=',
		window.esprima.delegate.createIdentifier(val_lev_vars.lev_var),  
		this.level.compile(bin_op_expr, true));
   assignment_stmt_3 = window.esprima.delegate.createExpressionStatement(assignment_aux);
	
	return {
   	compiled_stmts: [ 
   	   assignment_stmt_1, 
   	   assignment_stmt_2, 
   	   assignment_stmt_3
   	], 
   	new_vars: [
   	   val_lev_vars
   	]
   };
}; 


/*
 **********************************************************************************************************************
 * RECURSIVE CASES
 * ********************************************************************************************************************
 */


/*
 * Original code: s
 *   s = var x1, ..., xn; s' 
 *   C[s'] = s''               
 * Compiled code: 
 *   var _lab, _pc, _aux_1, _aux_2, aux_3, new_vars(s''); 
 *   var vars(s);
 *   _pc = _runtime.lat.bot;
 *   _lab = _runtime.initLab(vars(s), _pc); 
 *   s'' 
 * Runtimes: lat, lat.bot, initLab
 */
comp.compileProgram = function (st) {
	var compiled_stmt, 
	    compiled_stmts = [],
	    new_vars = [], 
	    i,
	    len,
	    original_vars_decl, 
	    stmts = st.body;
	     
	if (st.type !== esprima.Syntax.Program) {
	  throw new Error('Trying to compile program statement with non program');
	}
	
	i = stmts.length; 
	while (i--) {
		compiled_stmt = this.compile(stmts[i]);
		if (!compiled_stmt) {
		   continue; 
		} 
		if (compiled_stmt.hasOwnProperty('compiled_stmts')) {
		      compiled_stmts = compiled_stmt.compiled_stmts.concat(compiled_stmts);
		      new_vars = new_vars.concat(compiled_stmt.new_vars);
		} else {
	      compiled_stmts.shift(compiled_stmt);
		} 
	}
	
	original_vars_decl = this.utils.getProgDeclarations(st); 
	
	return this.createCompiledProgram(compiled_stmts, new_vars, original_vars_decl); 
}; 


comp.createCompiledProgram = function (compiled_stmts, new_vars, original_vars_decl) {
   var compiled_prog_stmts = [];
   
	//Compute the declaration of the compiler's internal variables
	//var _lab, _pc, _aux_1, _aux_2, _aux_3, new_vars(s'); 
	str = 'var {0}, {1}, {2}, {3}, {4}';
	str = $.validator.format(str, this.identifiers.consts.LAB_IDENT, 
		this.identifiers.consts.PC_IDENT, this.identifiers.getAuxIdentifierStr(1), 
		this.identifiers.getAuxIdentifierStr(2), this.identifiers.getAuxIdentifierStr(3));   
	new_vars_str = this.utils.newVarsToString(new_vars); 
	if (new_vars_str != '') {
		str += ', ' + new_vars_str; 
	}
	str += ';'; 
	internal_vars_decl = window.util.parseStmt(str);
   compiled_prog_stmts.push(internal_vars_decl); 
	
	//Compute the declaration of the original variables
	//var vars(s);
	if (original_vars_decl) {
		 original_vars_decl = $.extend(true, {}, original_vars_decl);
		 compiled_prog_stmts.push(original_vars_decl);
	} 
	
	//_pc = _runtime.lat.bot; 
	str = '{0} = {1}.bot; ';
	str = $.validator.format(str, this.identifiers.consts.PC_IDENT, 
		this.identifiers.getRuntimeMemberExprStr('lat')); 
	assignment_1 = window.util.parseStmt(str);
	compiled_prog_stmts.push(assignment_1);
	
	//_lab = _runtime.initLab(vars(s), _pc); 
	decl_vars_array_expr = this.utils.buildDeclVarsArrayExpr(original_vars_decl);
	args = [ 
	   decl_vars_array_expr, 
	   window.esprima.delegate.createIdentifier(this.identifiers.consts.PC_IDENT),
   ]; 
	init_lab_call = window.esprima.delegate.createCallExpression(
		window.esprima.delegate.createIdentifier(this.identifiers.getRuntimeMemberExprStr('initLab')), 
		args
	);
	init_lab_assignment = window.esprima.delegate.createAssignmentExpression(
		'=',
		window.esprima.delegate.createIdentifier(this.identifiers.consts.LAB_IDENT),  
		init_lab_call); 
	init_lab_assignment = window.esprima.delegate.createExpressionStatement(init_lab_assignment); 
	compiled_prog_stmts.push(init_lab_assignment); 
	
	compiled_prog_stmts = compiled_prog_stmts.concat(compiled_stmts);
	
	return esprima.delegate.createProgram(compiled_prog_stmts);  
}; 


comp.compileBlockStmt = function(st) {
   var compiled_stmt, 
       compiled_stmts = [], 
       i, 
       len, 
       new_vars = [], 
       stmts = st.body;

   i = stmts.length;
   while (i--) {
      compiled_stmt = this.compile(stmts[i]);
      if (!compiled_stmt) {
		   continue; 
		} 
      if (compiled_stmt.hasOwnProperty('compiled_stmts')) {
         compiled_stmts = compiled_stmt.compiled_stmts.concat(compiled_stmts);
         new_vars = new_vars.concat(compiled_stmt.new_vars);
      } else {
         compiled_stmts.shift(compiled_stmt);  
      }
   }
   
   return {
   	compiled_stmts: [ esprima.delegate.createBlockStatement(compiled_stmts) ],
   	new_vars: new_vars 
   }; 
};


comp.compileExprStmt = function(expr_stmt) {
	var compiled_st; 
   if (expr_stmt.type !== esprima.Syntax.ExpressionStatement) {
      throw new Error('Trying to compile expression statement with non expression statement');
   }
   compiled_st = comp.compile(expr_stmt.expression);
   if (!compiled_st.hasOwnProperty('compiled_stmts')) {
   	compiled_st = {
   		compiled_stmts: [ esprima.delegate.createExpressionStatement(compiled_st) ], 
   		new_vars: [ ]
      }; 
   }
   return compiled_st;
}; 


comp.compileAssignmentExpr = function (assign_expr) {
   if (assign_expr.left.type == 'MemberExpression') {
      return this.compilePropertyUpdateExp(assign_expr);  
   } else {
   	return this.compileVarAssignmentExpr(assign_expr); 
   }
}; 


/*
 * Original Code: x[ê_1] = ê_2 
 * Compilied Code:
 * _runtime.isValidPropertyAccess(x, ê_1); 
 * if(_runtime.internalHasOwnProperty(x, ê_1)) {
 *   _runtime.enforce(_runtime.lat.lub(C_l[x], C_l[ê_1], _pc), _runtime.getPropLev(x, ê_1));	
 * } else {
 *   _runtime.enforce(_runtime.lat.lub(C_l[x], _lev_i, _pc), _runtime.getStructLev(x));   
 * }
 * _runtime.setPropLev(x, _val_i, _runtime.lat.lub(C_l[x], _lev_i, C_l[ê_2], _pc)); 
 * x[ê_1] = ê_2; 
 */
comp.compilePropertyUpdateExp = function (prop_updt_expr) {
	var call_stmt, 
	    compiled_prop_updt, 
	    enforce_stmt_1_str,
	    enforce_stmt_2_str, 
	    if_stmt, 
	    new_val_expr, 
	    new_val_expr_str, 
	    new_val_level_expr, 
	    new_val_level_expr_str, 
	    obj_ident, 
	    obj_level_expr, 
	    obj_level_expr_str, 
	    prop_expr, 
	    prop_expr_str, 
	    prop_level_expr, 
	    prop_level_expr_str, 
	    str, 
	    type_validation_stmt; 

   // _runtime.isValidPropertyAccess(x, ê_1);
   obj_ident = prop_updt_expr.left.object.name;
   prop_expr = $.extend(true, {}, prop_updt_expr.left.property);
	prop_expr_str = window.util.printExprST(prop_expr);
	str = '_runtime.isValidPropertyAccess({0}, {1});'; 
	str = $.validator.format(str, obj_ident, prop_expr_str); 
	type_validation_stmt = window.util.parseStmt(str);
	
	//_runtime.enforce(_runtime.lat.lub(C_l[x], C_l[ê_1], _pc), _runtime.getPropLev(x, ê_1))
	obj_level_expr = this.level.compileIdentifierExpr(obj_ident);
	obj_level_expr_str = window.util.printExprST(obj_level_expr);
	prop_level_expr = this.level.compile(prop_expr); 
	prop_level_expr_str = window.util.printExprST(prop_level_expr);
	str = '{4}.enforce({4}.lat.lub({0}, {1}, {5}), {4}.getPropLev({2}, {3}));';
	enforce_stmt_1_str = $.validator.format(str, 
		obj_level_expr_str, prop_level_expr_str, obj_ident, prop_expr_str,  
		this.identifiers.consts.RUNTIME_IDENT, 
		this.identifiers.consts.PC_IDENT 
		);   
	
	//_runtime.enforce(_runtime.lat.lub(C_l[x], C_l[ê_1]), _runtime.getStructLev(x))
	str = '{3}.enforce({3}.lat.lub({0}, {1}, {4}), {3}.getStructLev({2}));';
	enforce_stmt_2_str = $.validator.format(str, obj_level_expr_str, prop_level_expr_str, obj_ident, 
		this.identifiers.consts.RUNTIME_IDENT, 
		this.identifiers.consts.PC_IDENT);   
	
	// if(_runtime.internalHasOwnProperty(x, ê_1)) { enforce_1 } else { enforce_2 }
	str = 'if({4}.internalHasOwnProperty({0}, {1})) { {2} } else { {3} }'; 
	str = $.validator.format(str, obj_ident, prop_expr_str, 
		enforce_stmt_1_str, enforce_stmt_2_str, this.identifiers.consts.RUNTIME_IDENT);
	if_stmt = window.util.parseStmt(str);
	
	// _runtime.setPropLev(x, ê_1, _runtime.lat.lub(C_l[x], C_l[ê_1], C_l[ê_2], _pc));
	new_val_expr = $.extend(true, {}, prop_updt_expr.right);
	new_val_expr_str = window.util.printExprST(new_val_expr);
	new_val_level_expr = this.level.compile(new_val_expr);
	new_val_level_expr_str = window.util.printExprST(new_val_level_expr);
	str = '{5}.setPropLev({0}, {1}, {5}.lat.lub({2}, {3}, {4}, {6}));';
	str = $.validator.format(str, obj_ident, prop_expr_str, obj_level_expr_str, 
		prop_level_expr_str, new_val_level_expr_str, 
		this.identifiers.consts.RUNTIME_IDENT, 
		this.identifiers.consts.PC_IDENT); 
	call_stmt = window.util.parseStmt(str);
	
	//  x[ê_1] = ê_2;
	str = '{0}[{1}] = {2};'; 
	str = $.validator.format(str, obj_ident, prop_expr_str, new_val_expr_str);
	compiled_prop_updt = window.util.parseStmt(str);
	
	return {
	   compiled_stmts: [
	      type_validation_stmt,
	      if_stmt,
	      call_stmt, 
	      compiled_prop_updt
	   ], 
	   new_vars: [ ]
   }; 
}; 


comp.compileVarAssignmentExpr = function (var_assignment_exp) {
	var compiled_right_side, 
	    original_right_side;
	original_right_side = var_assignment_exp.right; 
	compiled_right_side = this.compile(original_right_side); 
   if (compiled_right_side.hasOwnProperty('compiled_stmts')) {
      // right side is very simple expression
      return this.compileSimpleVarAssignmentExpr(var_assignment_exp.left.name, original_right_side, compiled_right_side); 	
   } else {
   	// right side is simple expression
   	return this.compileVerySimplVarAssignmentExpr(var_assignment_exp.left.name, original_right_side, compiled_right_side); 
   }
};


/*
 * Original Code: x = ê, where ê is simple
 * C[ê] = s, _vali, _levi
 * Compiled Code: 
 * s
 * _runtime.enforce(_pc, C_l[x]); 
 * _runtime.setVarLev('x', _lev_i, _lab); 
 * x = _vali; 
 */
comp.compileSimpleVarAssignmentExpr = function (ident, original_right_side, compiled_right_side) {
   var compiled_assignment, 
       enforce_stmt, 
       left_side_level_expr, 
       left_side_level_expr_str, 
       lev_var_ident, 
       set_var_stmt, 
       str, 
       val_var_ident; 
   
   //_runtime.enforce(_pc, C_l[x]);
   left_side_level_expr = this.level.compileIdentifierExpr(ident);
   left_side_level_expr_str = window.util.printExprST(left_side_level_expr);
   str = '{2}.enforce({1}, {0});';
   str = $.validator.format(str, left_side_level_expr_str, 
   	this.identifiers.consts.PC_IDENT,
   	this.identifiers.consts.RUNTIME_IDENT);
   enforce_stmt = window.util.parseStmt(str);
   
   //_runtime.setVarLev('x', _lev_i, _lab);
   lev_var_ident = compiled_right_side.new_vars[0].lev_var; 
   str = '{2}.setVarLev(\'{0}\', {1}, {3});';
   str = $.validator.format(str, ident, lev_var_ident, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.LAB_IDENT);
   set_var_stmt = window.util.parseStmt(str);
   
   //x = _vali;
   val_var_ident = compiled_right_side.new_vars[0].val_var; 
	str = '{0} = {1};'; 
	str = $.validator.format(str, ident, val_var_ident);
	compiled_assignment = window.util.parseStmt(str);
	
	compiled_right_side.compiled_stmts.push(enforce_stmt); 
	compiled_right_side.compiled_stmts.push(set_var_stmt); 
	compiled_right_side.compiled_stmts.push(compiled_assignment);
	
	return compiled_right_side;     
}; 


/*
 * Original Code: x = ê, where ê is very simple
 * Compiled Code: 
 * _runtime.enforce(_pc, C_l[x]); 
 * _runtime.setVarLev('x', _runtime.lat.lub(C_l[ê], _pc), _lab); 
 * x = ê; 
 */
comp.compileVerySimplVarAssignmentExpr = function (ident, original_right_side, compiled_right_side) {
   var compiled_assignment, 
       compiled_right_side_expr_str,
       enforce_stmt, 
       left_side_level_expr, 
       left_side_level_expr_str,
       right_side_level_expr, 
       right_side_level_expr_str,
       set_var_level_stmt,   
       str; 
   
   //_runtime.enforce(_pc, C_l[x]);
   left_side_level_expr = this.level.compileIdentifierExpr(ident);
   left_side_level_expr_str = window.util.printExprST(left_side_level_expr);
   str = '{2}.enforce({1}, {0});';
   str = $.validator.format(str, left_side_level_expr_str, 
   	this.identifiers.consts.PC_IDENT, 
   	this.identifiers.consts.RUNTIME_IDENT);
   enforce_stmt = window.util.parseStmt(str);
   
   //_runtime.setVarLev('x', _runtime.lat.lub(C_l[ê], _pc), _lab); 
   right_side_level_expr = this.level.compile(original_right_side);
   right_side_level_expr_str = window.util.printExprST(right_side_level_expr);
   str = '{2}.setVarLev(\'{0}\', {2}.lat.lub({1}, {3}), {4});';
   str = $.validator.format(str, ident, 
   	right_side_level_expr_str, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT,
   	this.identifiers.consts.LAB_IDENT); 
   set_var_level_stmt = window.util.parseStmt(str);
   
   //assignement
   compiled_right_side_expr_str = window.util.printExprST(compiled_right_side); 
   str = '{0} = {1};'; 
   str = $.validator.format(str, ident, compiled_right_side_expr_str); 
   compiled_assignment = window.util.parseStmt(str);
   	
   return {
   	compiled_stmts: [
   	   enforce_stmt, 
   	   set_var_level_stmt, 
   	   compiled_assignment 
   	], 
   	new_vars: [ ]
   }     	
};

/* Original Code: x[ê]
   Compiled Code: 
   _runtime.isValidPropertyAccess(x, ê);
   _val_i = x[ê]; 
   _lev_i = C_l[x[ê]]; 
*/ 
comp.compilePropLookUpExpr = function (prop_lookup_expr) {
	var assignment_aux, 
	    assignment_stmt_1, 
	    assignment_stmt_2, 
	    obj_ident, 
	    prop_expr, 
	    prop_expr_str, 
	    str, 
	    type_validation_stm; 
	    
	// _runtime.isValidPropertyAccess(x, ê_1);
   obj_ident = prop_lookup_expr.object.name;
   prop_expr = $.extend(true, {}, prop_lookup_expr.property);
	prop_expr_str = window.util.printExprST(prop_expr);
	str = '{2}.isValidPropertyAccess({0}, {1});'; 
	str = $.validator.format(str, obj_ident, prop_expr_str, 
		this.identifiers.consts.RUNTIME_IDENT); 
	type_validation_stmt = window.util.parseStmt(str);
	
	val_lev_vars = this.identifiers.getFreeValLevVars();
	
	// _val_i = x[ê];
	assignment_aux = window.esprima.delegate.createAssignmentExpression(
		'=',
		window.esprima.delegate.createIdentifier(val_lev_vars.val_var),  
		prop_lookup_expr); 
	assignment_stmt_1 = window.esprima.delegate.createExpressionStatement(assignment_aux);
	 
	// _lev_i = C_l[x[ê]]; 
	assignment_aux = window.esprima.delegate.createAssignmentExpression(
		'=',
		window.esprima.delegate.createIdentifier(val_lev_vars.lev_var),  
		this.level.compile(prop_lookup_expr));
   assignment_stmt_2 = window.esprima.delegate.createExpressionStatement(assignment_aux);
	
   return {
   	compiled_stmts: [
   	   type_validation_stmt, 
   	   assignment_stmt_1, 
   	   assignment_stmt_2
   	], 
   	new_vars: [
   	   val_lev_vars
   	]
   };
};


/*
 * Original Code: {} 
 * Compilied Code:
 * _vali = _runtime.initObject(null, _pc); 
 * _levi = _pc; 
 */
comp.compileObjectExpr = function (obj_expr) {
   var assignment_1, 
       assignment_2, 
       str, 
       val_lev_vars; 
        
   val_lev_vars = this.identifiers.getFreeValLevVars();
   
   //_vali = _runtime.initObject(null, _pc);
   str = '{0} = {1}.initObject(null, {2});';
   str = $.validator.format(str, val_lev_vars.val_var, 
      this.identifiers.consts.RUNTIME_IDENT,
   	this.identifiers.consts.PC_IDENT);  
   assignment_1 = window.util.parseStmt(str);
   
   // _levi = _pc;
   str = '{0} = {1};';
   str = $.validator.format(str, val_lev_vars.lev_var, this.identifiers.consts.PC_IDENT);  
   assignment_2 = window.util.parseStmt(str);
   
   return {
      compiled_stmts: [
         assignment_1, 
         assignment_2
      ], 
      new_vars: [ val_lev_vars ]
   };
}; 


/*
 * Original Code: [] 
 * Compilied Code:
 * _vali = _runtime.initArray(_pc); 
 * _levi = _pc; 
 */
comp.compileArrayExpr = function (obj_expr) {
   var assignment_1, 
       assignment_2, 
       str, 
       val_lev_vars; 
       
   val_lev_vars = this.identifiers.getFreeValLevVars();
   
   // _vali = _runtime.initArray(_pc); 
   str = '{0} = {1}.initArray({2});';
   str = $.validator.format(str, val_lev_vars.val_var, 
   	this.identifiers.consts.RUNTIME_IDENT,
   	this.identifiers.consts.PC_IDENT 
   	);  
   assignment_1 = window.util.parseStmt(str);
   
   // _levi = _pc; 
   str = '{0} = {1};';
   str = $.validator.format(str, val_lev_vars.lev_var, this.identifiers.consts.PC_IDENT);  
   assignment_2 = window.util.parseStmt(str);
   
   return {
      compiled_stmts: [
         assignment_1, 
         assignment_2
      ], 
      new_vars: [ val_lev_vars ]
   };
}; 


comp.compileCallExpr = function (call_expr) {
	switch (call_expr.callee.type) { 
	   case 'Identifier':
	      switch (call_expr.callee.name) {
	      	case 'upgVar':     return this.compileUpgdVarExpr(call_expr); 
	      	case 'upgProp':    return this.compileUpgdPropExpr(call_expr); 
	      	case 'upgStruct':  return this.compileUpgdStructExpr(call_expr); 
	      	case 'upgLevel':   return this.compileUpgdLevelExpr(call_expr);
	      	case 'upgUrl':     return this.compileUpgdUrlExpr(call_expr)  
	         default:           return this.compileFunCallExpr(call_expr);	
	      }
	   case 'MemberExpression': return this.compileMethodCallExpr(call_expr); 
	   default: throw new Error('Invalid Method Call'); 
	}
}; 


/*
 * Original code: upgVar(x, l)
 * Compiled code:
 *   _runtime.enforce(_pc, C_l[x]); 
 *   _runtime.setVarLev('x', _runtime.lat.lub(C_l[x], l), _lab);
 */
comp.compileUpgdVarExpr = function (call_exp_st) {
	var compiled_stmt_1,
	    compiled_stmt_2,  
	    str, 
	    var_identifier, 
	    var_level_expr, 
	    var_level_expr_str, 
	    new_level_str; 
	    
	//_runtime.enforce(_pc, C_l[x]);
	var_identifier = call_exp_st.arguments[0].name; 
	var_level_expr = this.level.compileIdentifierExpr(var_identifier); 
	var_level_expr_str = window.util.printExprST(var_level_expr);
   str = '{1}.enforce({2}, {0});';
   str = $.validator.format(str, var_level_expr_str, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT);
   compiled_stmt_1 = window.util.parseStmt(str);
	
	//_runtime.setVarLev('x', _runtime.lat.lub(C_l[x], l), _lab);
	new_level_str = call_exp_st.arguments[1].value; 
   str = '{3}.setVarLev(\'{0}\', {3}.lat.lub({1}, \'{2}\'), {4});';
	str = $.validator.format(str, var_identifier, 
		var_level_expr_str, new_level_str, 
		this.identifiers.consts.RUNTIME_IDENT,
		this.identifiers.consts.LAB_IDENT);
   compiled_stmt_2 = window.util.parseStmt(str);
   
   return {
      compiled_stmts: [ compiled_stmt_1, compiled_stmt_2 ],
      new_vars: [ ]
   };
};


/*
 * Original code: upgProp(x, prop, l)
 * Compiled code: 
 *    _runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getPropLev(x, prop)); 
 *    _runtime.setPropLev(x, prop, _runtime.lat.lub(l, _runtime.getPropLev(x,prop)));
 */
comp.compileUpgdPropExpr = function (call_exp_st) {
	var compiled_stmt,
	    new_level_str,
	    obj_identifier, 
	    obj_identifier_level_expr, 
	    obj_identifier_level_expr_str, 
	    prop_expr_str,   
	    str; 
	
	// _runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getPropLev(x, prop)); 
	obj_identifier = call_exp_st.arguments[0].name;
	obj_identifier_level_expr = this.level.compileIdentifierExpr(obj_identifier); 
	obj_identifier_level_expr_str = window.util.printExprST(obj_identifier_level_expr);
	prop_expr_str = call_exp_st.arguments[1].value;
	str = '{3}.enforce({3}.lat.lub({2}, {4}), {3}.getPropLev({0}, \'{1}\'));';
	str = $.validator.format(str, obj_identifier, prop_expr_str, 
		obj_identifier_level_expr_str, 
		this.identifiers.consts.RUNTIME_IDENT,
		this.identifiers.consts.PC_IDENT);  
   compiled_stmt_1 = window.util.parseStmt(str);
   
   // _runtime.setPropLev(x, prop, _runtime.lat.lub(l, _runtime.getPropLev(x,prop)));
	new_level_str = call_exp_st.arguments[2].value; 
   str = '{4}.setPropLev({0}, \'{1}\', {4}.lat.lub({2}, \'{3}\', {4}.getPropLev({0},\'{1}\')));';
	str = $.validator.format(str, obj_identifier, prop_expr_str, 
		obj_identifier_level_expr_str, new_level_str, 
		this.identifiers.consts.RUNTIME_IDENT);
   compiled_stmt_2 = window.util.parseStmt(str);
	
   return {
      compiled_stmts: [ compiled_stmt_1, compiled_stmt_2 ],
      new_vars: [ ]
   };
};


/*
 * Original code: upgStruct(x, l)
 * Compiled code: 
 *    _runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getStructLev(x)); 
 *    _runtime.setStructLev(x, _lat.lub(l, _runtime.getStructLev(x)));
 */
comp.compileUpgdStructExpr = function (call_exp_st) {
	var compiled_stmt_1, 
	    compiled_stmt_2,
	    new_level_str, 
	    obj_identifier, 
	    obj_identifier_level_expr, 
	    obj_identifier_level_expr_str, 
	    str; 
	
   //_runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getStructLev(x)); 
   obj_identifier = call_exp_st.arguments[0].name;
   obj_identifier_level_expr = this.level.compileIdentifierExpr(obj_identifier); 
   obj_identifier_level_expr_str = window.util.printExprST(obj_identifier_level_expr);
   str = '{2}.enforce({2}.lat.lub({1}, {3}), {2}.getStructLev({0}));';
   str = $.validator.format(str, obj_identifier, 
   	obj_identifier_level_expr_str, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT);  
   compiled_stmt_1 = window.util.parseStmt(str);
   
   //_runtime.setStructLev(x, _runtime.lat.lub(l, _runtime.getStructLev(x)));
   new_level_str = call_exp_st.arguments[1].value; 
   str = '{2}.setStructLev({0}, {2}.lat.lub(\'{1}\', {2}.getStructLev({0})));';
   str = $.validator.format(str, obj_identifier, 
   	new_level_str,
   	this.identifiers.consts.RUNTIME_IDENT);  
   compiled_stmt_2 = window.util.parseStmt(str);
   
   return {
      compiled_stmts: [ compiled_stmt_1, compiled_stmt_2 ],
      new_vars: [ ]
   };
};


/*
 * Original code: upgLevel(x, l)
 * Compiled code: 
 *    _runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getLevel(x)); 
 *    _runtime.setLevel(x, _runtime.lat.lub(l, _runtime.getLevel(x)));
 */
comp.compileUpgdLevelExpr = function(call_exp_st) {
   var compiled_stmt_1, 
	    compiled_stmt_2,
	    new_level_str, 
	    obj_identifier, 
	    obj_identifier_level_expr, 
	    obj_identifier_level_expr_str, 
	    str; 
	
	// _runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getLevel(x));
   obj_identifier = call_exp_st.arguments[0].name;
   obj_identifier_level_expr = this.level.compileIdentifierExpr(obj_identifier); 
   obj_identifier_level_expr_str = window.util.printExprST(obj_identifier_level_expr);
   str = '{2}.enforce({2}.lat.lub({1}, {3}), {2}.getLevel({0}));';
   str = $.validator.format(str, obj_identifier, 
   	obj_identifier_level_expr_str, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT);  
   compiled_stmt_1 = window.util.parseStmt(str);
   
	// _runtime.setLevel(x, _runtime.lat.lub(l, _runtime.getLevel(x)));
   new_level_str = call_exp_st.arguments[1].value; 
   str = '{2}.setLevel({0}, {2}.lat.lub(\'{1}\', {2}.getLevel({0})));';
   str = $.validator.format(str, obj_identifier, 
   	new_level_str, 
   	this.identifiers.consts.RUNTIME_IDENT);  
   compiled_stmt_2 = window.util.parseStmt(str);
   
   return {
      compiled_stmts: [ compiled_stmt_1, compiled_stmt_2 ],
      new_vars: [ ]
   };
};


/*
 * Original code: upgUrl(x, level)
 * Compiled code: 
 *    _runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getUrlLevel(x)); 
 *    _runtime.setUrlLevel(x, _runtime.lat.lub(l, _runtime.getUrlLevel(x)));
 */
comp.compileUpgdUrlExpr = function(call_exp_st) {
	var compiled_stmt_1, 
	    compiled_stmt_2,
	    new_level_str, 
	    str, 
	    url_expr, 
	    url_expr_str, 
	    url_level_expr, 
	    url_level_expr_str; 
	
	// _runtime.enforce(_runtime.lat.lub(C_l[x], _pc), _runtime.getUrlLevel(x));
   url_expr = call_exp_st.arguments[0];
   url_expr_str = window.util.printExprST(url_expr);
   url_level_expr = this.level.compile(url_expr); 
   url_level_expr_str = window.util.printExprST(url_level_expr);
   str = '{2}.enforce({2}.lat.lub({1}, {3}), {2}.getUrlLevel({0}));';
   str = $.validator.format(str, url_expr_str, 
   	url_level_expr_str, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT);  
   compiled_stmt_1 = window.util.parseStmt(str);
   
	// _runtime.setUrlLevel(x, _runtime.lat.lub(l, _runtime.getUrlLevel(x)));
   new_level_str = call_exp_st.arguments[1].value; 
   str = '{2}.setUrlLevel({0}, {2}.lat.lub(\'{1}\', {2}.getUrlLevel({0})));';
   str = $.validator.format(str, url_expr_str, new_level_str, 
   	this.identifiers.consts.RUNTIME_IDENT);  
   compiled_stmt_2 = window.util.parseStmt(str);
   
   return {
      compiled_stmts: [ compiled_stmt_1, compiled_stmt_2 ],
      new_vars: [ ]
   };
};


/*
 * Function call
 * Original Code: x(ê) 
 * Compilied Code: s_1 = C[x(ê)], s_2 = C_u[x(ê)]
 * if(x._instrumented) {
 * 	s_1
 * } else {
 * 	s_2
 * }
 *  
 */
comp.compileFunCallExpr = function (funcall_expr) {
	var compiled_if,
	    compiled_instrumented_call_expr_stmts, 
	    compiled_uninstrumented_call_expr_stmts,
	    fun_indentifier_str,  
	    str; 
	
	fun_indentifier_str = funcall_expr.callee.name;
	val_lev_vars = this.identifiers.getFreeValLevVars();
	
	// if(x._instrumented) {  } else {  }
	str = 'if({0}.{1}) {} else {}'; 
	str = $.validator.format(str, fun_indentifier_str, 
		this.identifiers.consts.INSTRUMENTED_PROP_IDENT); 
	compiled_if = window.util.parseStmt(str);
	
	
	compiled_uninstrumented_call_expr_stmts = this.compileUnInstrumentedFunCallExpr(funcall_expr, val_lev_vars);
	compiled_instrumented_call_expr_stmts = this.compileInstrumentedFunCallExpr(funcall_expr, val_lev_vars); 
	
	compiled_if.consequent.body = compiled_instrumented_call_expr_stmts; 
	compiled_if.alternate.body = compiled_uninstrumented_call_expr_stmts;
	
	return {
      compiled_stmts: [
         compiled_if
      ],
      new_vars: [ val_lev_vars ]
   };
}


/*
 * Instrumented function call
 * Original Code: x(ê) 
 * Compilied Code:
 * _aux_1 = x(ê, C_l[ê], _runtime.lat.lub(C_l[x], _pc));
 * _val_i = aux_1._val; 
 * _lev_i = aux_1._lev; 
 */
comp.compileInstrumentedFunCallExpr = function (call_expr, val_lev_vars) { 
   var args_exprs, 
       args_levels_array_expr,
       assignment_1,  
       assignment_2, 
       assignment_3, 
       context_level, 
       identifier_level_expr, 
       identifier_level_expr_str, 
       lub_member_expr, 
       str;  
   
   //_runtime.lat.lub(C_l[x], _pc);
   identifier_level_expr = this.level.compileIdentifierExpr(call_expr.callee.name);
   identifier_level_expr_str = window.util.printExprST(identifier_level_expr);
   str = '{1}.lat.lub({0}, {2})';  
   str = $.validator.format(str, identifier_level_expr_str,
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT);
   context_level_expr = window.util.parseExpr(str);
   
   //_aux_1 = x(ê, C_l[ê], _runtime.lat.lub(C_l[x], _pc)); 
   args_exprs = $.extend(true, [], call_expr.arguments);
   args_levels_array_expr = this.level.computeArgumentLevels(call_expr.arguments);
   args_exprs.push(args_levels_array_expr); 
   args_exprs.push(context_level_expr);
   compiled_call_expr = window.esprima.delegate.createCallExpression(
      window.esprima.delegate.createIdentifier(call_expr.callee.name),
      args_exprs);
   assignment_1 = window.esprima.delegate.createAssignmentExpression(
      '=', 
      this.identifiers.getAuxIdentifier(1),
      compiled_call_expr); 
   assignment_1 = window.esprima.delegate.createExpressionStatement(assignment_1); 
   
   //_val_i = aux_1._val;
   str = '{0} = {2}.{1};'; 
   str = $.validator.format(str, 
   	val_lev_vars.val_var,
   	this.identifiers.consts.VAL_PROP_IDENT, 
   	this.identifiers.getAuxIdentifierStr(1));
   assignment_2 = window.util.parseStmt(str);
   
   //_lev_i = aux_1._lev;
   str = '{0} = {2}.{1};';
   str = $.validator.format(str, 
   	val_lev_vars.lev_var, 
   	this.identifiers.consts.LEV_PROP_IDENT, 
   	this.identifiers.getAuxIdentifierStr(1));
   assignment_3 = window.util.parseStmt(str);
   
	return [assignment_1, assignment_2, assignment_3];  
}; 


/*
 * Unisntrumented function call
 * Original code: f(ê_1, ..., ê_n)
 * Instrumented Code: 
 * 
 *  _aux_1 = _runtime.lat.lub(_runtime.getVarLev('f', _lab), _pc) 
 * 
 *  _enforceInstr = _runtime.getEnforceFun(f);
 *  _computeReturnLevel = _runtime.getComputeRetLevelFun(f);
 *  _computeReturnValue = _runtime.getComputeRetVal(f);
 *  _updateArgsLevels = _runtime.getUpdtArgsLevelsFun(f);
 *  _processArg = _runtime.getProcessArg(f);
 *  
 *  _enforceInstr(ê_1, ..., ê_n, args_levels, _aux_1);
 *  _aux_2 = f(_processArg(ê_1, 1), ...,_processArg(ê_n, n));  
 *  _val_i = _computeReturnValue(ê_1, ..., ê_n, args_levels, _aux_1, _aux_2); 
 *  _lev_i = _computeReturnLevel(ê_1, ..., ê_n, args_levels, _aux_1, _aux_2);
 *  _updtArgsLevels(ê_1, ..., ê_n, args_levels, _aux_1, _aux_2); 
 */
comp.compileUnInstrumentedFunCallExpr = function (funcall_expr, val_lev_vars) {
	var args_levels_array_expr, 
	    assignment_expr_aux, 
	    call_expr_aux, 
	    compiled_args,
	    compiled_args_aux, 
	    compiled_stmt_1, 
	    compiled_stmt_2,
	    compiled_stmt_3,
	    compiled_stmt_4,
	    compiled_stmt_5,
	    compiled_stmt_6,
	    compiled_stmt_7,
	    compiled_stmt_8,  
	    compiled_stmt_9, 
	    compiled_stmt_10,
	    compiled_stmt_11,  
	    compiled_stmt_12, 
	    fun_indentifier_str,
	    i, 
	    len,  
	    processed_args, 
	    str;
	
	fun_indentifier_str = funcall_expr.callee.name; 
   
   // ctxt_level => _aux_1 = _runtime.lat.lub(_runtime.getVarLev('f', _lab), _pc)
	str = '{1} = {2}.lat.lub({2}.getVarLev(\'{0}\', {3}), {4});'; 
	str = $.validator.format(str, fun_indentifier_str, 
		this.identifiers.getAuxIdentifierStr(1), 
		this.identifiers.consts.RUNTIME_IDENT, 
		this.identifiers.consts.LAB_IDENT,
		this.identifiers.consts.PC_IDENT);
	compiled_stmt_1 = window.util.parseStmt(str);
	
	// (x1, ..., xn, args_levels, _aux_1)
	compiled_args = $.extend(true, [], funcall_expr.arguments); 
	args_levels_array_expr = this.level.computeArgumentLevels(compiled_args);
	compiled_args.push(args_levels_array_expr); 
	compiled_args.push(this.identifiers.getAuxIdentifier(1));
	
	//_enforceInstr = _runtime.getEnforceFun(f);
	str = '_enforceInstr = {1}.getEnforceFun({0});'; 
	str = $.validator.format(str, fun_indentifier_str, 
		this.identifiers.consts.RUNTIME_IDENT);
	compiled_stmt_2 = window.util.parseStmt(str);
	
	//_computeRetLevel = _runtime.getComputRetLevelFun(f);
	str = '_computeReturnLevel = {1}.getComputeRetLevelFun({0});';
	str = $.validator.format(str, fun_indentifier_str, 
		this.identifiers.consts.RUNTIME_IDENT);
	compiled_stmt_3 = window.util.parseStmt(str);
	
	//_computeReturnVal = _runtime.getComputeRetVal(f);
	str = '_computeReturnValue = {1}.getComputeRetValFun({0});'; 
	str = $.validator.format(str, fun_indentifier_str, 
		this.identifiers.consts.RUNTIME_IDENT);
	compiled_stmt_4 = window.util.parseStmt(str);
	
	//_updtArgsLevels = _runtime.getUpdtArgsLevelsFun(f);
	str = '_updateArgsLevels = {1}.getUpdtArgsLevelsFun({0});';
	str = $.validator.format(str, fun_indentifier_str, 
		this.identifiers.consts.RUNTIME_IDENT);
	compiled_stmt_5 = window.util.parseStmt(str);

	//_processArg = _runtime.getProcessArg(f);
	str = '_processArg = {1}.getProcessArg({0});';
	str = $.validator.format(str, fun_indentifier_str, 
		this.identifiers.consts.RUNTIME_IDENT);
	compiled_stmt_6 = window.util.parseStmt(str);

   //_enforceInstr(x1, ..., xn, args_levels, _aux_1);
   call_expr_aux = window.esprima.delegate.createCallExpression(
      window.esprima.delegate.createIdentifier('_enforceInstr'),
      $.extend(true, [], compiled_args));
   compiled_stmt_7 = window.esprima.delegate.createExpressionStatement(call_expr_aux);  
   
   // evaluator = function($) { return eval($); }
   str = 'evaluator = function($) { return eval($); };';
   compiled_stmt_8 = window.util.parseStmt(str);
   
   // (_processArg(ê_1, 1, evaluator), ...,_processArg(ê_n, n, evaluator))
   compiled_args_aux = []; 
   for(i = 0, len = funcall_expr.arguments.length; i < len; i++) {
   	call_expr_aux = window.esprima.delegate.createCallExpression(
         window.esprima.delegate.createIdentifier('_processArg'),
         [
            $.extend(true, {}, funcall_expr.arguments[i]), 
            window.esprima.delegate.createLiteral2(i+1),
            window.esprima.delegate.createIdentifier('evaluator')
         ]);
      compiled_args_aux[i] = call_expr_aux;  
   }
   
   // _aux_2 = f(_processArg(ê_1, 1), ...,_processArg(ê_n, n));
   call_expr_aux = window.esprima.delegate.createCallExpression(
   	window.esprima.delegate.createIdentifier(fun_indentifier_str),
      compiled_args_aux);
   assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
   	'=', 
   	this.identifiers.getAuxIdentifier(2), 
   	call_expr_aux
   );
   compiled_stmt_9 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux);
   
   // (x1, ..., xn, args_levels, _aux_1, _aux_2)
   compiled_args.push(this.identifiers.getAuxIdentifier(2));
   
   //_val_i = _computeRetVal(x1, ..., xn, args_levels, _aux_1, _aux_2); 
   call_expr_aux = window.esprima.delegate.createCallExpression(
      window.esprima.delegate.createIdentifier('_computeReturnValue'), 
      $.extend(true, [], compiled_args)
   );
   assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
   	'=', 
   	window.esprima.delegate.createIdentifier(val_lev_vars.val_var), 
   	$.extend(true, [], call_expr_aux)
   );
   compiled_stmt_10 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux);
   
   //_lev_i = _computeRetLevel(x1, ..., xn, args_levels, _aux_1, _aux_2);
   call_expr_aux = window.esprima.delegate.createCallExpression(
      window.esprima.delegate.createIdentifier('_computeReturnLevel'),
      $.extend(true, [], compiled_args));
   assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
   	'=', 
   	window.esprima.delegate.createIdentifier(val_lev_vars.lev_var), 
   	call_expr_aux
   );   
   compiled_stmt_11 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux);
   
   //_updtArgsLevels(x1, ..., xn, args_levels, _aux_1, _aux_2); 
   call_expr_aux = window.esprima.delegate.createCallExpression(
      window.esprima.delegate.createIdentifier('_updateArgsLevels'),
      $.extend(true, [], compiled_args));
	compiled_stmt_12 = window.esprima.delegate.createExpressionStatement(call_expr_aux);
	
	return  [
      compiled_stmt_1,
      compiled_stmt_2, 
      compiled_stmt_3, 
      compiled_stmt_4, 
      compiled_stmt_5, 
      compiled_stmt_6,
      compiled_stmt_7, 
      compiled_stmt_8, 
      compiled_stmt_9, 
      compiled_stmt_10, 
      compiled_stmt_11, 
      compiled_stmt_12 
   ];
};


/*
 * Method call
 * Original Code: x[ê_1](ê_2, ..., ê_n) 
 * Compilied Code: s_1 = C[x[ê_1](ê_2, ..., ê_n) ], s_2 = C_u[x[ê_1](ê_2, ..., ê_n) ]
 * _runtime.isValidPropertyAccess(x, ê_1);
 * if(x[ê_1]._instrumented) {
 * 	s_1
 * } else {
 * 	s_2
 * }
 *  
 */
comp.compileMethodCallExpr = function (method_call_expr, val_lev_vars) {
	var compiled_if,
	    compiled_instrumented_method_call_expr_stmts, 
	    compiled_uninstrumented_method_call_expr_stmts,
	    member_expr, 
	    member_expr_str,
	    obj_identifier_str,  
	    str, 
	    prop_str, 
	    type_validation_statement; 
	
	member_expr = $.extend(true, {}, method_call_expr.callee.property);
	member_expr_str = window.util.printExprST(member_expr);
	obj_identifier_str = method_call_expr.callee.object.name; 
	
	if (!val_lev_vars) {
	   val_lev_vars = this.identifiers.getFreeValLevVars();
	}
	
	// if (method_call_expr.callee.property.type === 'Literal') {
      // prop_str = '\'' + method_call_expr.callee.property.value + '\''; 	
	// } else {
		// prop_str =  method_call_expr.callee.property.name; 
	// }
	
	// _runtime.isValidPropertyAccess(x, ê_1);
	str = '{2}.isValidPropertyAccess({0}, {1});'; 
	str = $.validator.format(str, 
		obj_identifier_str, 
		member_expr_str,
		this.identifiers.consts.RUNTIME_IDENT);
	type_validation_statement = window.util.parseStmt(str);
	
	
	
	str = 'if({0}[{1}][\'{2}\']) {} else {}'; 
	str = $.validator.format(str, 
		obj_identifier_str, 
		member_expr_str,
		this.identifiers.consts.INSTRUMENTED_PROP_IDENT); 
	compiled_if = window.util.parseStmt(str);

	compiled_uninstrumented_method_call_expr_stmts = this.compileUnInstrumentedMethodCallExpr(method_call_expr, val_lev_vars);
	compiled_instrumented_method_call_expr_stmts = this.compileInstrumentedMethodCallExpr(method_call_expr, val_lev_vars);
	
	compiled_if.consequent.body = compiled_instrumented_method_call_expr_stmts; 
	compiled_if.alternate.body = compiled_uninstrumented_method_call_expr_stmts;
	
	return {
      compiled_stmts: [
         type_validation_statement, 
         compiled_if
      ],
      new_vars: [ val_lev_vars ]
   };
}


/*
 * Original Code: x[ê_1](ê_2) 
 * Compilied Code:
 * _aux_1 = _runtime.lat.lub(C_l[x], C_l[ê_1], _runtime.getPropLev(x, ê_1), _pc);
 * _aux_1 = x[ê_1](ê_2, C_l[ê_2], _aux_1);
 * _val_i = aux_1._val; 
 * _lev_i = aux_1._lev;  
 */
comp.compileInstrumentedMethodCallExpr = function (method_call_expr, val_lev_vars) {
   var arg_level_exp, 
       args_exprs, 
       args_levels_exprs, 
       assignment_1, 
       assignment_2, 
       compiled_args_exprs, 
       compiled_method_call, 
       compiled_member_expr, 
       obj_level_expr, 
       obj_level_expr_str, 
       obj_ident, 
       prop_expr, 
       prop_expr_str, 
       prop_level_expr, 
       prop_level_expr_str, 
       str, 
       val_lev_vars;

   // _aux_1 = _runtime.lat.lub(C_l[x], C_l[e_1], _runtime.getPropLev(x, ê_1), _pc);
   obj_ident = method_call_expr.callee.object.name;
   prop_expr = $.extend(true, {}, method_call_expr.callee.property);
   prop_expr_str = window.util.printExprST(prop_expr);
   obj_level_expr = this.level.compileIdentifierExpr(obj_ident);
   obj_level_expr_str = window.util.printExprST(obj_level_expr);
   prop_level_expr = this.level.compile(prop_expr);
   prop_level_expr_str = window.util.printExprST(prop_level_expr);
   str = '{4} = {5}.lat.lub({2}, {3}, {5}.getPropLev({0}, {1}), {6});';
   str = $.validator.format(str, obj_ident, prop_expr_str, 
   	obj_level_expr_str, prop_level_expr_str, 
   	this.identifiers.getAuxIdentifierStr(1), 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT);
   assignment_1 = window.util.parseStmt(str);

   //_aux_1 = x[ê_1](ê_2, C_l[ê_2], args_levels, _aux_1);
   // {3}: array with the level of each argument
   args_exprs = method_call_expr.arguments;
   args_levels_exprs = this.level.computeArgumentLevels(args_exprs);
   compiled_args_exprs = args_exprs;
   compiled_args_exprs.push(args_levels_exprs);
   compiled_args_exprs.push(this.identifiers.getAuxIdentifier(1));
   compiled_member_expr = $.extend(true, {}, method_call_expr.callee);
   compiled_method_call = window.esprima.delegate.createCallExpression(compiled_member_expr, compiled_args_exprs);
   assignment_2 = window.esprima.delegate.createAssignmentExpression(
   	'=',
   	this.identifiers.getAuxIdentifier(1),
   	compiled_method_call
   ); 
   assignment_2 = window.esprima.delegate.createExpressionStatement(assignment_2); 

   //_val_i = _aux_1._val;
   str = '{0} = {1}.{2};'; 
   str = $.validator.format(str, val_lev_vars.val_var, 
   	this.identifiers.getAuxIdentifierStr(1),
   	this.identifiers.consts.VAL_PROP_IDENT);
   assignment_3 = window.util.parseStmt(str);

   //_lev_i = _aux_1._lev;
   str = '{0} = {1}.{2};';
   str = $.validator.format(str, val_lev_vars.lev_var,
   	this.identifiers.getAuxIdentifierStr(1),
   	this.identifiers.consts.LEV_PROP_IDENT);
   assignment_4 = window.util.parseStmt(str);
   
   return [
      assignment_1, 
      assignment_2, 
      assignment_3, 
      assignment_4
   ];
};


/*
 * Uninstrumented method call
 * Original Code: x[ê_1](ê_2, ..., ê_n) 
 * Compilied Code:
 * 
 *  _aux_1 = _runtime.lat.lub(C_l[x], C_l[ê_1], _runtime.getPropLev(x, ê_1), _pc);
 *  _enforceInstr = _runtime.getEnforceMethod(x, ê_1);
 *  _computeRetLevel = _runtime.getComputeRetLevelMethod(x, ê_1);
 *  _updtArgsLevels = _runtime.getUpdtArgsLevelsMethod(x, ê_1);
 *  _processRetValue = _runtime.getProcessRetValue(x, ê_1);
 * 
 *  _enforceInstr(ê_1, ê_2, ..., ê_n, args_levels, _aux_1); 
 *  _val_i = x[ê_1](ê_2, ..., ê_n); 
 *  _val_i = _processRetValue(ê_1, ê_2, ..., ê_n, args_levels, _aux_1, _val_i);
 *  _lev_i = _computeRetLevel(ê_1, ê_2, ..., ê_n, args_levels, _aux_1, _val_i);
 *  _updtArgsLevels(ê_1, ê_2, ..., ê_n, args_levels, _aux_1, _val_i); 
 */
comp.compileUnInstrumentedMethodCallExpr = function (method_call_expr, val_lev_vars) {
	var aux_identifier, 
	    args_exprs, 
	    args_levels_array_expr, 
	    assignment_expr_aux, 
	    call_expr_aux, 
	    compiled_stmt_1,
	    compiled_stmt_2,
	    compiled_stmt_3,
	    compiled_stmt_4,
	    compiled_stmt_5,
	    compiled_stmt_6,
	    compiled_stmt_7,
	    compiled_stmt_8,
	    compiled_stmt_9, 
	    compiled_stmt_10, 
	    obj_identifier_str, 
	    obj_level_expr, 
	    obj_level_expr_str, 
	    prop_expr, 
	    prop_expr_level, 
	    prop_expr_level_str, 
	    prop_expr_str, 
	    str, 
	    val_lev_vars; 
	
	// _aux_1
	aux_identifier = this.identifiers.getAuxIdentifier(1); 
	
   // _aux_1 = _runtime.lat.lub(C_l[x], C_l[_1], _runtime.getPropLev(x, ê_1), _pc);
   obj_identifier_str = method_call_expr.callee.object.name; 
   obj_level_expr = this.level.compileIdentifierExpr(obj_identifier_str);
   obj_level_expr_str = window.util.printExprST(obj_level_expr);
   prop_expr = $.extend(true, {}, method_call_expr.callee.property);
   prop_expr_str = window.util.printExprST(prop_expr);
   prop_expr_level = this.level.compile(prop_expr);
   prop_expr_level_str = window.util.printExprST(prop_expr_level);
	str = '{4} = {5}.lat.lub({2}, {3}, {5}.getPropLev({0}, {1}), {6});' 
   str = $.validator.format(str, obj_identifier_str, 
   	prop_expr_str, obj_level_expr_str, 
   	prop_expr_level_str, 
   	this.identifiers.getAuxIdentifierStr(1), 
   	this.identifiers.consts.RUNTIME_IDENT,
   	this.identifiers.consts.PC_IDENT);
   compiled_stmt_1 = window.util.parseStmt(str);
	
   //_enforceInstr = _runtime.getEnforceMethod(x, ê_1);
   str = '_enforceInstr = {2}.getEnforceMethod({0}, {1});'; 
   str = $.validator.format(str, obj_identifier_str, 
   	prop_expr_str,
   	this.identifiers.consts.RUNTIME_IDENT);
   compiled_stmt_2 = window.util.parseStmt(str); 
	
	//_computeRetLevel = _runtime.getComputeRetLevelMethod(x, ê_1);
	str = '_computeReturnLevel = {2}.getComputeRetLevelMethod({0}, {1});'; 
   str = $.validator.format(str, obj_identifier_str, 
   	prop_expr_str, 
   	this.identifiers.consts.RUNTIME_IDENT);
   compiled_stmt_3 = window.util.parseStmt(str);  
   
   //_updtArgsLevels = _runtime.getUpdtArgsLevelsMethod(x, ê_1);
   str = '_updateArgsLevels = {2}.getUpdtArgsLevelsMethod({0}, {1});'; 
   str = $.validator.format(str, obj_identifier_str, 
   	prop_expr_str,
   	this.identifiers.consts.RUNTIME_IDENT);
   compiled_stmt_4 = window.util.parseStmt(str);
   
   //_processRetValue = _runtime.getProcessRetValue(x, ê_1);
   str = '_processReturnValue = {2}.getProcessRetValue({0}, {1});';
   str = $.validator.format(str, obj_identifier_str, 
   	prop_expr_str,
   	this.identifiers.consts.RUNTIME_IDENT);
   compiled_stmt_5 = window.util.parseStmt(str);
   
   //(x, ê_2, ..., ê_n, args_levels, ctxt_level)
   args_exprs = [ window.esprima.delegate.createIdentifier(obj_identifier_str) ]; 
   args_exprs = args_exprs.concat($.extend(true, [], method_call_expr.arguments));
   args_levels_array_expr = this.level.computeArgumentLevels(args_exprs);
   args_exprs.push(args_levels_array_expr); 
   args_exprs.push(aux_identifier); 
	
	//_enforceInstr(x, ê_2, ..., ê_n, args_levels, ctxt_level);
   call_expr_aux = window.esprima.delegate.createCallExpression(
	   window.esprima.delegate.createIdentifier('_enforceInstr'), 
	   $.extend(true, [], args_exprs)	
	); 
	compiled_stmt_6 = window.esprima.delegate.createExpressionStatement(call_expr_aux);  
	
	//_val_i = x[ê_1](ê_2, ..., ê_n); 
	call_expr_aux = $.extend(true, {}, method_call_expr);
	assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
		'=', 
		window.esprima.delegate.createIdentifier(val_lev_vars.val_var), 
		call_expr_aux
	);
	compiled_stmt_7 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux);  
	
	//_val_i = _processRetValue(ê_1, ê_2, ..., ê_n, args_levels, ctxt_level, _val_i);
	args_exprs.push(window.esprima.delegate.createIdentifier(val_lev_vars.val_var));
	call_expr_aux = window.esprima.delegate.createCallExpression(
		window.esprima.delegate.createIdentifier('_processReturnValue'), 
		 $.extend(true, [], args_exprs)
	);
	args_exprs.pop(); 
	assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
		'=', 
		window.esprima.delegate.createIdentifier(val_lev_vars.val_var), 
		call_expr_aux
	);
	compiled_stmt_8 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux);   
	
	//_lev_i = _computeRetLevel(x, ê_2, ..., ê_n, args_levels, ctxt_level);
	call_expr_aux = window.esprima.delegate.createCallExpression(
		window.esprima.delegate.createIdentifier('_computeReturnLevel'), 
		 $.extend(true, [], args_exprs)
	); 
   assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
	   '=', 
		window.esprima.delegate.createIdentifier(val_lev_vars.lev_var), 
		call_expr_aux
	);
	compiled_stmt_9 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux);  
	
	//_updtArgsLevels(x, ê_2, ..., ê_n, args_levels, ctxt_level); 
	call_expr_aux = window.esprima.delegate.createCallExpression(
	   window.esprima.delegate.createIdentifier('_updateArgsLevels'), 
	   $.extend(true, [], args_exprs)	
	); 
	compiled_stmt_10 = window.esprima.delegate.createExpressionStatement(call_expr_aux);  
	
	return [
      compiled_stmt_1, 
      compiled_stmt_2, 
      compiled_stmt_3, 
      compiled_stmt_4, 
      compiled_stmt_5, 
      compiled_stmt_6, 
      compiled_stmt_7, 
      compiled_stmt_8, 
      compiled_stmt_9, 
      compiled_stmt_10
   ];
};


comp.compileConstructorCallExpr = function(constructor_call_expr) {
   var compiled_if, 
       compiled_instrumented_constructor_call_expr_stmts, 
       compiled_uninstrumented_constructor_call_expr_stmts, 
       constructor_expr, 
       constructor_expr_str, 
       str;

   constructor_expr = $.extend(true, {}, constructor_call_expr.callee);
   constructor_expr_str = window.util.printExprST(constructor_expr);
   val_lev_vars = this.identifiers.getFreeValLevVars();

   str = 'if({0}.{1}) {} else {}';
   str = $.validator.format(str, constructor_expr_str, 
   	this.identifiers.consts.INSTRUMENTED_PROP_IDENT);
   compiled_if = window.util.parseStmt(str);

   compiled_uninstrumented_constructor_call_expr_stmts = this.compileUnInstrumentedConstructorCallExpr(constructor_call_expr, val_lev_vars);
   compiled_instrumented_constructor_call_expr_stmts = this.compileInstrumentedConstructorCallExpr(constructor_call_expr, val_lev_vars);

   compiled_if.consequent.body = compiled_instrumented_constructor_call_expr_stmts;
   compiled_if.alternate.body = compiled_uninstrumented_constructor_call_expr_stmts;

   return {
      compiled_stmts : [compiled_if],
      new_vars : [val_lev_vars]
   };
}


/*
 * Original Code: new x(ê) 
 * Compilied Code:
 * _lev_i = _runtime.lat.lub(C_l[x], _pc); 
 * _val_i = _runtime.initObject(x.prototype, _lev_i);
 * _aux_1 = _runtime.call(x, _val_i, ê, args_levels, _lev_i); 
 * if(aux_1) { 
 * 	_lev_i = _aux_1._val; 
 *    _val_i = _aux_1._lev; 
 * } 
 */
comp.compileInstrumentedConstructorCallExpr = function (constructor_call_expr, val_lev_vars) {
   var args_exprs, 
       args_levels_array_expr,
       assignment_1,
       assignment_2,  
       assignment_3,
       compiled_args_exprs, 
       if_stmt_st, 
       obj_ident, 
       obj_level_expr,
       obj_level_expr_str, 
       str, 
       val_lev_vars; 
        
   //_lev_i = _runtime.lat.lub(C_l[x], _pc);
   obj_ident = constructor_call_expr.callee.name; 
   obj_level_expr = this.level.compileIdentifierExpr(obj_ident);
   obj_level_expr_str = window.util.printExprST(obj_level_expr);
   str = '{0} = {2}.lat.lub({1}, {3});'; 
   str = $.validator.format(str, val_lev_vars.lev_var, 
   	obj_level_expr_str, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	this.identifiers.consts.PC_IDENT);
   assignment_1 = window.util.parseStmt(str);
   
   //_val_i = _runtime.initObject(x.prototype, _lev_i);
   str = '{0} = {3}.initObject({1}.prototype, {2});'; 
   str = $.validator.format(str, val_lev_vars.val_var, 
   	obj_ident, 
   	val_lev_vars.lev_var, 
   	this.identifiers.consts.RUNTIME_IDENT);
   assignment_2 = window.util.parseStmt(str);
   
   //_aux_1 = _runtime.call(x, _val_i, ê, C_l[ê], _lev_i);  
   str = '{0} = {1}.call();'; 
   str = $.validator.format(str, 
   	this.identifiers.getAuxIdentifierStr(1),
   	this.identifiers.consts.RUNTIME_IDENT); 
   assignment_3 = window.util.parseStmt(str); 
   args_exprs = constructor_call_expr.arguments;
   args_levels_array_expr = this.level.computeArgumentLevels(args_exprs);
   compiled_args_exprs = $.extend(true, [], args_exprs); 
   compiled_args_exprs.unshift(window.esprima.delegate.createIdentifier(obj_ident)); 
   compiled_args_exprs.unshift(window.esprima.delegate.createIdentifier(val_lev_vars.val_var)); 
   compiled_args_exprs.push(args_levels_array_expr);
   compiled_args_exprs.push(window.esprima.delegate.createIdentifier(val_lev_vars.lev_var));
   assignment_3.expression.right.arguments = compiled_args_exprs; 
   
   // if (_aux_1) { _lev_i = _aux._val;  _val_i = _aux._lev; }
   str = 'if ({2}) { {0} = {2}.{3}; {1} =  {2}.{4}; }'; 
   str = $.validator.format(str, val_lev_vars.lev_var, 
   	val_lev_vars.val_var, 
   	this.identifiers.getAuxIdentifierStr(1), 
   	this.identifiers.consts.VAL_PROP_IDENT, 
   	this.identifiers.consts.LEV_PROP_IDENT);   
   if_stmt_st = window.util.parseStmt(str);
   
   return [
      assignment_1, 
      assignment_2, 
      assignment_3, 
      if_stmt_st
   ];
}


/*
 * Uninstrumented method call
 * Original Code: new F(ê_1, ..., ê_n) 
 * Compilied Code:
 *  _aux_1 = _runtime.lat.lub(C_l[F], _pc);
 *  _enforceInstr = _runtime.getEnforceConstructor(F);
 *  _computeRetLevel = _runtime.getNewObjLevel(F);
 *  _updtArgsLevels = _runtime.getUpdtArgsLevelsConstructor(F);
 *  
 *  _enforceInstr(ê_1, ..., ê_n, args_levels, _aux_1); 
 *  _val_i = new F(ê_1, ..., ê_n);
 *  _lev_i = _computeRetLevel(ê_1, ..., ê_n, args_levels, _aux_1, _val_i);
 *  _updtArgsLevels(ê_1, ..., ê_n, args_levels, _aux_1); 
*/
comp.compileUnInstrumentedConstructorCallExpr = function (constructor_call_expr, val_lev_vars) {
	var args_exprs,
	    assignment_expr_aux,  
	    aux_identifier, 
	    call_expr_aux, 
	    compiled_stmt_1, 
	    compiled_stmt_2,
	    compiled_stmt_3,
	    compiled_stmt_4,
	    compiled_stmt_5,
	    compiled_stmt_6, 
	    compiled_stmt_7,
	    compiled_stmt_8,
	    obj_level_expr,  
	    obj_level_expr_str,
	    obj_identifier_str,
	    str, 
	    val_lev_vars;
	
	// aux_identifier
	aux_identifier = this.identifiers.getAuxIdentifier(1); 
	
	// _aux_1 = _runtime.lat.lub(C_l[F], _pc);
	obj_identifier_str = constructor_call_expr.callee.name; 
	obj_level_expr = this.level.compileIdentifierExpr(obj_identifier_str); 
	obj_level_expr_str = window.util.printExprST(obj_level_expr);
	str = '{0} = {1}.lat.lub({2}, {3});';
	str = $.validator.format(str, 
		this.identifiers.getAuxIdentifierStr(1),
		this.identifiers.consts.RUNTIME_IDENT,
		obj_level_expr_str, 
		this.identifiers.consts.PC_IDENT); 
	compiled_stmt_1 = window.util.parseStmt(str);
	
	//_enforceInstr = _runtime.getEnforceConstructor(F);
	str = '_enforceInstr = {0}.getEnforceConstructor({1});'; 
	str = $.validator.format(str,
		this.identifiers.consts.RUNTIME_IDENT, 
		obj_identifier_str);
	compiled_stmt_2 = window.util.parseStmt(str);
	
	//_computeRetLevel = _runtime.getComputeRetLevelFun(F);
	str = '_computeRetLevel = {0}.getNewObjLevel({1});'; 
	str = $.validator.format(str,
		this.identifiers.consts.RUNTIME_IDENT, 
		obj_identifier_str);
	compiled_stmt_3 = window.util.parseStmt(str);
	
	//_updtArgsLevels = _runtime.getUpdtArgsLevelsFun(F);
	str = '_updtArgsLevels = {0}.getUpdtArgsLevelsConstructor({1});';
	str = $.validator.format(str, 
		this.identifiers.consts.RUNTIME_IDENT,
		obj_identifier_str);
	compiled_stmt_4 = window.util.parseStmt(str);
	
	//(ê_1, ê_2, ..., ê_n, args_levels, _aux_1)
	args_exprs = $.extend(true, [], constructor_call_expr.arguments);
   args_levels_array_expr = this.level.computeArgumentLevels(args_exprs);
   args_exprs.push(args_levels_array_expr); 
   args_exprs.push(aux_identifier); 
   
   //_enforceInstr(ê_1, ..., ê_n, args_levels, _aux_1);
	call_expr_aux = window.esprima.delegate.createCallExpression(
	   window.esprima.delegate.createIdentifier('_enforceInstr'), 
	   $.extend(true, [], args_exprs)	
	); 
	compiled_stmt_5 = window.esprima.delegate.createExpressionStatement(call_expr_aux);
	
	//_val_i = x[ê_1](ê_2, ..., ê_n); 
	call_expr_aux = $.extend(true, {}, constructor_call_expr);
	assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
		'=', 
		window.esprima.delegate.createIdentifier(val_lev_vars.val_var), 
		call_expr_aux
	);
	compiled_stmt_6 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux);  
	
	args_exprs.push(window.esprima.delegate.createIdentifier(val_lev_vars.val_var)); 
	
	//_lev_i = _computeRetLevel(ê_1, ..., ê_n, args_levels, _aux_1, _val_i);
	call_expr_aux = window.esprima.delegate.createCallExpression(
		window.esprima.delegate.createIdentifier('_computeRetLevel'), 
		 $.extend(true, [], args_exprs)
	); 
   assignment_expr_aux = window.esprima.delegate.createAssignmentExpression(
	   '=', 
		window.esprima.delegate.createIdentifier(val_lev_vars.lev_var), 
		call_expr_aux
	);
	compiled_stmt_7 = window.esprima.delegate.createExpressionStatement(assignment_expr_aux); 
	
	//_updtArgsLevels(ê_1, ..., ê_n, args_levels, _aux_1); 
	call_expr_aux = window.esprima.delegate.createCallExpression(
	   window.esprima.delegate.createIdentifier('_updtArgsLevels'), 
	   $.extend(true, [], args_exprs)	
	); 
	compiled_stmt_8 = window.esprima.delegate.createExpressionStatement(call_expr_aux);  
	
	return [
      compiled_stmt_1, 
      compiled_stmt_2, 
      compiled_stmt_3, 
      compiled_stmt_4, 
      compiled_stmt_5,  
      compiled_stmt_6, 
      compiled_stmt_7, 
      compiled_stmt_8
   ];	
};


/*
 * Original Code: function(x_1, ..., x_n) { s }, C[s] = s', new_vars
 * Compiled body: s'' = 
 *     var _lab, _aux, new_vars; 
 *     var vars(s);
 *     _pc = _runtime.lat.lub(_pc, arguments.callee._pc); 
 *     _lab = _runtime.initLab(arguments.callee._lab, ['x_1', ..., 'x_n'], args_levels, vars(s), _pc); 
 *     s' 
 * Compiled function literal: 
 *  _val_i = function(x_1, ..., x_n, args_levels, _external_pc) { s'' };  
 *  _val_i._lab = _lab; 
 *  _val_i._pc = _pc;
 *  _val_i._instrumented = true;  
 *  _lev_i = _pc; 
 */
comp.compileFunctionLiteralExpr = function (funlit_exp) {
	var assignment_1, 
	    assignment_2,
	    assignment_3,
	    assignment_4,
	    assignment_5,
	    compiled_funlit, 
	    val_lev_vars, 
	    str;
	     
	compiled_funlit = this.computeNewFunctionLiteral(funlit_exp); 
	val_lev_vars = this.identifiers.getFreeValLevVars();
	
	//_val_i = function(x_1, ..., x_n, args_levels, _external_pc) { s'' };  
	assignment_1 = window.esprima.delegate.createAssignmentExpression(
	   '=',
	   window.esprima.delegate.createIdentifier(val_lev_vars.val_var), 
	   compiled_funlit 
   );
   assignment_1 = window.esprima.delegate.createExpressionStatement(assignment_1);
   
   //_val_i._lab = _lab; 
   str = ' {0}.{1} = {2};'
   str = $.validator.format(str, val_lev_vars.val_var, 
   	this.identifiers.consts.LAB_PROP_IDENT, 
   	this.identifiers.consts.LAB_IDENT);
   assignment_2 = window.util.parseStmt(str);
   
   //_val_i._pc = _pc; 
   str = '{0}.{1} = {2};' 
   str = $.validator.format(str, val_lev_vars.val_var, 
   	this.identifiers.consts.PC_PROP_IDENT,
   	this.identifiers.consts.PC_IDENT);
   assignment_3 = window.util.parseStmt(str);
   
   //_val_i._instrumented = true;  
   str = '{0}.{1} = true;' 
   str = $.validator.format(str, val_lev_vars.val_var, 
   	this.identifiers.consts.INSTRUMENTED_PROP_IDENT);
   assignment_4 = window.util.parseStmt(str);
   
   //_lev_i = _pc; 
   str = '{0} = {1}; '; 
   str = $.validator.format(str, val_lev_vars.lev_var, 
   	this.identifiers.consts.PC_IDENT);
   assignment_5 = window.util.parseStmt(str);
	
	return {
		compiled_stmts: [ assignment_1, assignment_2, assignment_3, assignment_4, assignment_5 ] , 
		new_vars: [ val_lev_vars ]
	}; 
};


comp.computeNewFunctionLiteral = function (funlit_exp) {
	var args,
	    args_array_expr, 
	    assignment_1, 
	    body_stmts = [], 
	    compiled_body,
	    compiled_params, 
	    decl_vars_array_expr,
	    fun_scope_lab_ident,
	    funlit_body, 
	    init_lab_assignment,
	    init_lab_call, 
	    internal_vars_decl,   
	    new_vars_str,
	    original_vars_decl,
	    str;
	
	//Compute the new params: (x_1, ..., x_n, args_levels, _pc)
	compiled_params = $.extend(true, [], funlit_exp.params); 
	compiled_params.push(window.esprima.delegate.createIdentifier(this.identifiers.consts.ARGS_LEVELS_PARAM));
	compiled_params.push(window.esprima.delegate.createIdentifier(this.identifiers.consts.PC_IDENT));  
	
	//Compute the declaration of the compiler's internal variables
	//var _lab, _aux_1, _aux_2, _aux_3, new_vars(s'); 
	str = 'var {0}, {1}, {2}, {3}';
	str = $.validator.format(str, 
		this.identifiers.consts.LAB_IDENT, 
		this.identifiers.getAuxIdentifierStr(1),
		this.identifiers.getAuxIdentifierStr(2),
		this.identifiers.getAuxIdentifierStr(3));
	compiled_body = this.compile(funlit_exp.body); 
	new_vars_str = this.utils.newVarsToString(compiled_body.new_vars); 
	if (new_vars_str != '') {
		str += ', ' + new_vars_str; 
	}
	str += ';'; 
	internal_vars_decl = window.util.parseStmt(str);
   body_stmts.push(internal_vars_decl); 
	
	//Compute the declaration of the original variables
	//var vars(s);
	original_vars_decl =  this.utils.getOriginalDeclarations(funlit_exp);
	if (original_vars_decl) {
		 original_vars_decl = $.extend(true, {}, original_vars_decl);
		 body_stmts.push(original_vars_decl);
	} 
	
	//_pc = _runtime.lat.lub(_pc, arguments.callee._pc);
	str = '{0} = {1}.lat.lub({0}, arguments.callee.{2});';
	str = $.validator.format(str, 
		this.identifiers.consts.PC_IDENT, 
		this.identifiers.consts.RUNTIME_IDENT, 
		this.identifiers.consts.PC_PROP_IDENT);  
	assignment_1 = window.util.parseStmt(str);
	body_stmts.push(assignment_1);
	
	// _lab = _runtime.initLab(); 
	str = '{0} = {1}.initLab();'
	str = $.validator.format(str, 
		this.identifiers.consts.LAB_IDENT,
		this.identifiers.consts.RUNTIME_IDENT);
	init_lab_assignment = window.util.parseStmt(str);	
	
	// (arguments.callee._lab, ['x_1', ..., 'x_n'], args_levels, vars(s), _pc)
	args_array_expr = this.utils.buildArgsArrayExpr(funlit_exp.params);
	decl_vars_array_expr = this.utils.buildDeclVarsArrayExpr(original_vars_decl); 
	str = 'arguments.callee.{0}';
	str = $.validator.format(str, this.identifiers.consts.LAB_PROP_IDENT);   
	fun_scope_lab_ident = window.util.parseExpr(str);
	args = [ 
	   fun_scope_lab_ident, 
	   args_array_expr,
	   window.esprima.delegate.createIdentifier(this.identifiers.consts.ARGS_LEVELS_PARAM),  
	   decl_vars_array_expr, 
	   window.esprima.delegate.createIdentifier(this.identifiers.consts.PC_IDENT),
   ];
   
   // _lab = _runtime.initLab(arguments.callee._lab, ['x_1', ..., 'x_n'], args_levels, vars(s), _pc); 
   init_lab_assignment.expression.right.arguments = args; 
   body_stmts.push(init_lab_assignment); 
   
	// Add the compiled body to the stmts
	compiled_body.compiled_stmts[0].body = body_stmts.concat(compiled_body.compiled_stmts[0].body);
	
	// compute instrumented function literal
	return window.esprima.delegate.createFunctionExpression(null, compiled_params, [], compiled_body.compiled_stmts[0]);  
}; 


/*
 * Original Code: return ê - where ê is very simple
 * Compiled Code:
 * return {_val: ê, _lev: _lat.lub(C_l[ê], _pc)}
 */
comp.processReturnStmt = function (ret_stmt) {
	var compiled_ret_stmt, 
	    prop_val, 
	    prop_lev, 
	    ret_object, 
	    ret_val_expr, 
	    ret_level_expr, 
	    ret_level_expr_str, 
	    str; 
	
	//_val: ê
	ret_val_expr = $.extend(true, {}, ret_stmt.argument);
   prop_val = window.esprima.delegate.createProperty('init',
       window.esprima.delegate.createIdentifier(this.VAL_PROP_IDENT), 
       ret_val_expr
   );
	
	//_lev: _lat.lub(C_l[ê], _pc)
	ret_level_expr = this.level.compile(ret_val_expr);
	ret_level_expr_str = window.util.printExprST(ret_level_expr);  
	str = '_lat.lub({0}, _pc)'; 
	str = $.validator.format(str, ret_level_expr_str);
	ret_level_expr = window.util.parseExpr(str); 
	prop_lev = window.esprima.delegate.createProperty('init',
       window.esprima.delegate.createIdentifier(this.LEV_PROP_IDENT), 
       ret_level_expr
   );
	
	//{_val: ê, _lev: _lat.lub(C_l[ê], _pc)}
	ret_object = window.esprima.delegate.createObjectExpression([
		prop_val, 
		prop_lev
	]); 
	//return {_val: ê, _lev: _lat.lub(C_l[ê], _pc)}
	compiled_ret_stmt = window.esprima.delegate.createReturnStatement(ret_object); 
		
   return {
   	compiled_stmts: [ compiled_ret_stmt ], 
   	new_vars: [ ]
   }; 
}; 


/*
 * Original Code: return ê - where ê is very simple
 * Compiled Code:
 * return {_val: ê, _lev: _runtime.lat.lub(C_l[ê], _pc)}
 */
comp.compileReturnStmt = function (ret_stmt) {
	var compiled_ret_stmt, 
	    prop_val, 
	    prop_lev, 
	    ret_object, 
	    ret_val_expr, 
	    ret_level_expr, 
	    ret_level_expr_str, 
	    str; 
	
	//_val: ê
	ret_val_expr = $.extend(true, {}, ret_stmt.argument);
   prop_val = window.esprima.delegate.createProperty('init',
       window.esprima.delegate.createIdentifier(this.identifiers.consts.VAL_PROP_IDENT), 
       ret_val_expr
   );
	
	//_lev: _runtime.lat.lub(C_l[ê], _pc)
	ret_level_expr = this.level.compile(ret_val_expr);
	ret_level_expr_str = window.util.printExprST(ret_level_expr);  
	str = '{0}.lat.lub({1}, {2})'; 
	str = $.validator.format(str,
		this.identifiers.consts.RUNTIME_IDENT,  
		ret_level_expr_str, 
		this.identifiers.consts.PC_IDENT);
	ret_level_expr = window.util.parseExpr(str); 
	prop_lev = window.esprima.delegate.createProperty('init',
       window.esprima.delegate.createIdentifier(this.identifiers.consts.LEV_PROP_IDENT), 
       ret_level_expr
   );
	
	//{_val: ê, _lev: _lat.lub(C_l[ê], _pc)}
	ret_object = window.esprima.delegate.createObjectExpression([
		prop_val, 
		prop_lev
	]); 
	//return {_val: ê, _lev: _lat.lub(C_l[ê], _pc)}
	compiled_ret_stmt = window.esprima.delegate.createReturnStatement(ret_object); 
		
   return {
   	compiled_stmts: [ compiled_ret_stmt ], 
   	new_vars: [ ]
   }; 
}; 


/*
 * Original Code: while(ê) { s }, C[s] = s'
 * Compiled Code: 
 * _pc_holder_i = _pc; 
 * _pc = _compile.lat.lub(_pc, C_l[ê]); 
 * while(ê) { s' }
 * _pc = _pc_holderi; 
 */
comp.compileWhileStmt = function (while_stmt) { 
   var assignment_1, 
       assignment_2, 
       assignment_3,
       compiled_body, 
       compiled_while,
       new_vars, 
       pc_holder_var, 
       pc_holder_ident, 
       str, 
       test_expr, 
       test_expr_str, 
       test_level_expr, 
       test_level_expr_str; 
   
   //_pc_holder_i = _pc;
   pc_holder_var = this.identifiers.getPcHolderVar();
   new_vars = [ pc_holder_var ];
   str = '{0} = {1}';
   str = $.validator.format(str, 
   	pc_holder_var.pc_holder,  
   	this.identifiers.consts.PC_IDENT);
   assignment_1 = window.util.parseStmt(str);
   
   //_pc = _runtime.lat.lub(_pc, C_l[ê]);
   test_expr = $.extend(true, {}, while_stmt.test);
   test_expr_str = window.util.printExprST(test_expr);
   test_level_expr = this.level.compile(test_expr);
   test_level_expr_str = window.util.printExprST(test_level_expr);
   str = '{0} = {1}.lat.lub({0}, {2});'; 
   str = $.validator.format(str,
   	this.identifiers.consts.PC_IDENT, 
   	this.identifiers.consts.RUNTIME_IDENT, 
   	test_level_expr_str);
   assignment_2 = window.util.parseStmt(str);
   
   //while(ê) { s' }
   compiled_body = this.compile(while_stmt.body); 
   compiled_while = esprima.delegate.createWhileStatement(test_expr, compiled_body.compiled_stmts[0]); 
   new_vars = new_vars.concat(compiled_body.new_vars); 
   
   //_pc = _pc_holderi; 
   str = '{0} = {1};'; 
   str = $.validator.format(str, 
   	this.identifiers.consts.PC_IDENT, 
   	pc_holder_ident);
   assignment_3 = window.util.parseStmt(str); 
   
   return {
   	compiled_stmts: [
   	   assignment_1,
   	   assignment_2,  
   	   compiled_while, 
   	   assignment_3
   	], 
   	new_vars: new_vars
   }  
};


/*
 * Original Code: if(ê) { s_1 } else { s_2 }, C[s_1] = s_1', C[s_2] = s_2' 
 * Compiled Code: 
 * _pc_holder_i = _pc; 
 * _pc = _runtime.lat.lub(_pc, C_l[ê]); 
 * if (ê) { s_1' } else { s_2' } 
 * _pc = _pc_holder_i;
 *  
 */
comp.compileIfStmt = function (if_stmt) { 
	var assignment_1, 
	    assignment_2, 
	    assignment_3, 
	    compiled_else_stmt,
	    compiled_if_stmt, 
	    compiled_then_stmt,
	    new_vars,
	    pc_holder_ident,  
	    pc_holder_var, 
	    str, 
	    test_expr, 
	    test_expr_str, 
	    test_level_expr, 
	    test_level_expr_str;
	
	// _pc_holder_i = _pc; 
	pc_holder_var = this.identifiers.getPcHolderVar();
	new_vars = [ pc_holder_var ];
	pc_holder_ident = pc_holder_var.pc_holder;  
   str = '{0} = {1}';
   str = $.validator.format(str, pc_holder_ident,
   	this.identifiers.consts.PC_IDENT);
   assignment_1 = window.util.parseStmt(str);
   
   // _pc = _runtime.lat.lub(_pc, C_l[ê]); 
   test_expr = $.extend(true, {}, if_stmt.test);
   test_expr_str = window.util.printExprST(test_expr);
   test_level_expr = this.level.compile(test_expr);
   test_level_expr_str = window.util.printExprST(test_level_expr);
   str = '{0} = {1}.lat.lub({0}, {2});'; 
   str = $.validator.format(str, 
   	this.identifiers.consts.PC_IDENT, 
   	this.identifiers.consts.RUNTIME_IDENT,
   	test_level_expr_str);
   assignment_2 = window.util.parseStmt(str);
	
	// if (ê) { s_1' } else { s_2' } 
	compiled_then_stmt = this.compile(if_stmt.consequent);
	compiled_else_stmt = this.compile(if_stmt.alternate); 
	compiled_if_stmt = window.esprima.delegate.createIfStatement(
      test_expr, 
      compiled_then_stmt.compiled_stmts[0],
      compiled_else_stmt ? compiled_else_stmt.compiled_stmts[0] : null); 
   new_vars = new_vars.concat(compiled_then_stmt.new_vars); 
   new_vars = compiled_else_stmt ? new_vars.concat(compiled_else_stmt.new_vars) : new_vars; 
	
	// _pc = _pc_holder_i
	str = '{0} = {1};';
	str = $.validator.format(str,
		this.identifiers.consts.PC_IDENT, 
		pc_holder_ident); 
	assignment_3 = window.util.parseStmt(str);
	
	return {
   	compiled_stmts: [
   	   assignment_1, 
   	   assignment_2, 
   	   compiled_if_stmt, 
   	   assignment_3
   	], 
   	new_vars: new_vars
   }  
}; 


// Levels

comp.level = {}; 

comp.level.compile = function(expr, with_pc){
	var level_expr, member_expr, str; 
	level_expr = comp.level.cases[expr.type](expr); 
	
	if(with_pc) {
		// _runtime.lat.lub(C_l[ê], _pc)
		str = '{0}.lat.lub'; 
		str =  $.validator.format(str, comp.identifiers.consts.RUNTIME_IDENT);
		member_expr = window.util.parseExpr(str);  
		level_expr = window.esprima.delegate.createCallExpression(
		    member_expr, 
		    [
		       level_expr, 
		       window.esprima.delegate.createIdentifier(comp.identifiers.consts.PC_IDENT)
		    ]); 
	}
	
	return level_expr; 
}; 

/*
 * original code: x 
 * compiled code: _runtime.getVarLev('x', _lab)
 */
comp.level.compileIdentifierExpr = function (ident) { 
   var str; 
   
   if ((typeof ident) !== 'string') {
   	ident = ident.name; 
   } 
   
   // {0}.getVarLev({1}, {2})
   str = '{0}.getVarLev(\'{1}\', {2})';
   str = $.validator.format(str, 
		comp.identifiers.consts.RUNTIME_IDENT, ident, comp.identifiers.consts.LAB_IDENT);   
	return window.util.parseExpr(str); 
}; 


/*
 * original code: v 
 * compiled code: _runtime.lat.bot
 */
comp.level.compileLiteralExpr = function () {
	return comp.level.latBotExp();  
};


/*
 * Original Code: this
 * Compiled Code: _runtime.getVarLev('this', _lab)
 */
comp.level.compileThisExpr = function () {
	var str; 
	// _runtime.getVarLev('this', _lab)
	str = '{0}.getVarLev(\'this\', {1})';
	str = $.validator.format(str, 
		comp.identifiers.consts.RUNTIME_IDENT, comp.identifiers.consts.LAB_IDENT);  
	return window.util.parseExpr(str);  
}; 


/*
 * Original Code: x[ê]
 * Compiled Code: _runtime.lat.lub(_runtime.getVarLev('x', _lab), C_l[ê], _runtime.getPropLev(x, ê))
 */
comp.level.compilePropLookUpExpr = function (prop_lookup_expr) {
	var obj_ident, 
	    prop_expr, 
	    prop_expr_str, 
	    prop_level_expr, 
	    prop_level_expr_str,
	    str; 
	
	obj_ident = prop_lookup_expr.object.name; 
	prop_expr = $.extend(true, {}, prop_lookup_expr.property); 
	prop_expr_str = window.util.printExprST(prop_expr);
	prop_level_expr = comp.level.compile(prop_expr); 
	prop_level_expr_str = window.util.printExprST(prop_level_expr);
	// _runtime.lat.lub(_runtime.getVarLev('x', _lab), C_l[ê], _runtime.getPropLev(x, ê))
	str = '{4}.lat.lub({4}.getVarLev(\'{0}\', {3}), {1}, {4}.getPropLev({0}, {2}))'; 
	str = $.validator.format(str, obj_ident, prop_level_expr_str, prop_expr_str, 
		comp.identifiers.consts.LAB_IDENT, comp.identifiers.consts.RUNTIME_IDENT);
	return window.util.parseExpr(str);  
}; 


/*
 * Original Code: ê_1 op ê_2
 * Compiled Code: _runtime.lat.lub(C_l[e_1], C_l[e_2])
 */
comp.level.compileBinOpExpr = function (binop_expr) {
	var left_level_expr, 
	    left_level_expr_str, 
	    right_level_expr, 
	    right_level_expr_str, 
	    str;
	     
	left_level_expr = comp.level.compile(binop_expr.left); 
	left_level_expr_str = window.util.printExprST(left_level_expr);
	right_level_expr = comp.level.compile(binop_expr.right); 
	right_level_expr_str = window.util.printExprST(right_level_expr);
	// _runtime.lat.lub(C_l[e_1], C_l[e_2])
	str = '{2}.lat.lub({0}, {1})'; 
	str = $.validator.format(str, left_level_expr_str, right_level_expr_str,
		comp.identifiers.consts.RUNTIME_IDENT); 
	return window.util.parseExpr(str);
}; 


/*
 * Original code op ê
 * compiled code: C_l[ê]
 */
comp.level.compileUnOpExpr = function (unop_expr) {
   return comp.level.compile(unop_expr.argument); 
};


comp.level.cases = {
	Identifier: comp.level.compileIdentifierExpr, 
	Literal: comp.level.compileLiteralExpr, 
	ThisExpression: comp.level.compileThisExpr, 
	MemberExpression: comp.level.compilePropLookUpExpr, 
	BinaryExpression: comp.level.compileBinOpExpr, 
	UnaryExpression: comp.level.compileUnOpExpr
}


comp.level.computeArgumentLevels = function(args){
	var arg, argLevels;
	argLevels = [];  
	for(var i=0, len=args.length; i<len; i++){
		arg = args[i]; 
		switch(arg.type){
			case "Identifier":
			    argLevels.push(comp.level.compileIdentifierExpr(arg.name));
			    break;  
			case "Literal": 
			    argLevels.push(comp.level.compileLiteralExpr()); 
			    break; 
		    default: throw new Error('error in arguments')
		}
	}
	return esprima.delegate.createArrayExpression(argLevels); 
}; 

/*
 * _runtime.lat.bot 
 */
comp.level.latBotExp = function() { 
	var str; 
	// _runtime.lat.bot
	str = '{0}.lat.bot'; 
	str = $.validator.format(str, comp.identifiers.consts.RUNTIME_IDENT); 
	return window.util.parseExpr(str);
}; 