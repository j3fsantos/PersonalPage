comp.identifiers = {}; 

comp.identifiers.consts = {
	AUX_IDENT: '_aux',
	LAB_IDENT: '_lab',
	LAB_PROP_IDENT: '_lab', 
	LEV_VAR_IDENT: '_lev_',
	LEV_PROP_IDENT: '_lev', 
	PC_IDENT: '_pc',   
	PC_HOLDER_IDENT: '_pc_holder_',
	PC_PROP_IDENT: '_pc', 
	VAL_VAR_IDENT: '_val_',
	VAL_PROP_IDENT: '_val',
	RUNTIME_IDENT: '_runtime',
	INSTRUMENTED_PROP_IDENT: '_instrumented', 
	ARGS_LEVELS_PARAM: 'args_levels'
}; 

comp.identifiers.printState = function() {
	var lab, 
	    prop,
	    runtime,
	    str = ''; 
	lab = window[this.consts.LAB_IDENT];
	for(prop in lab) {
		str += 'variable: ' + prop + ', value: ' + window[prop] + ', level: ' + lab[prop] + '\n';    
	}
	return str; 
};

comp.identifiers.getAuxIdentifier = function (i) {
	return esprima.delegate.createIdentifier(this.getAuxIdentifierStr(i));  
};

comp.identifiers.getAuxIdentifierStr = function (i) {
   if (isFinite(i)) {
   	return this.consts.AUX_IDENT + '_' + i; 
   } else {
   	return this.consts.AUX_IDENT + '_1';  
   }
};

comp.identifiers.getRuntimeMemberExpr = function (prop_name) {
	var delegate = window.esprima.delegate;
	return delegate.createMemberExpression('[',
	   delegate.createIdentifier(this.consts.RUNTIME_IDENT), 
	   delegate.createLiteral2(prop_name));
}

comp.identifiers.getRuntimeMemberExprStr = function (prop_name) {
	return this.consts.RUNTIME_IDENT + '.' + prop_name;  
}

comp.identifiers.getFreeValLevVars = (function () {
   var i = 0;
   return function() {
      var val_var = this.consts.VAL_VAR_IDENT + i,
          lev_var = this.consts.LEV_VAR_IDENT + i; 
      i++;
      return {
      	val_var: val_var, 
      	lev_var: lev_var
      };
   }
})();

comp.identifiers.getPcHolderVar = (function() {
   var i = 0;
   return function() {
      i++;
      return { pc_holder: this.consts.PC_HOLDER_IDENT+i };
   };
})();

comp.identifiers.randomizeIdentifiers = function() {
   var n; 
   n = Math.random() * 1000; 
   n = Math.floor(n); 
   for (var prop in comp.identifiers.consts) {
   	comp.identifiers.consts[prop] = comp.identifiers.consts[prop] + '_' + n + '_';  
   }	
   return n; 
}; 

