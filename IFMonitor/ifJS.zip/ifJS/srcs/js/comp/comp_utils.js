comp.utils = {};

comp.utils.isSimpleCallExp = function(call_exp) { 
	var type = call_exp.type, 
	    fun_type = call_exp.callee.type;
	return (type === esprima.Syntax.CallExpression) && (fun_type === esprima.Syntax.Identifier); 
};

comp.utils.buildArgsArrayExpr = function (params) {
   var i, 
       len, 
       literals_arr = []; 
       
   for (i = 0, len = params.length; i < len; i++) {
      literals_arr.push(window.esprima.delegate.createLiteral2(params[i].name));   	 
   }
   
   return esprima.delegate.createArrayExpression(literals_arr);   
};

comp.utils.buildDeclVarsArrayExpr = function (decl_stmt) {
   var declarations, 
       i, 
       len,
       literals_arr = []; 
   
   declarations = decl_stmt ? decl_stmt.declarations : []; 
   for (i = 0, len = declarations.length; i < len; i++) {
      literals_arr.push(window.esprima.delegate.createLiteral2(declarations[i].id.name));  
   }
   
   return esprima.delegate.createArrayExpression(literals_arr); 
};


comp.utils.getOriginalDeclarations = function (funlit_exp) {
	var body; 
	body = funlit_exp.body.body 
   if ((body.length > 0) && (body[0].type === 'VariableDeclaration')) { 
      return body[0];
   }  	
   return null; 
};

comp.utils.getProgDeclarations = function(prog_exp) {
   var body = prog_exp.body; 
   if ((body.length > 0) && (body[0].type === 'VariableDeclaration')) {
   	return body[0];
   }
   return null; 
};


// new_vars_to_string
comp.utils.newVarsToString = function (new_vars) {
	var current_var, 
	    i, 
	    len = new_vars.length, 
	    new_vars_str = ''; 
	    
	i = len; 
	while(i--) {
		if(new_vars_str !== '') new_vars_str += ', '; 
		current_var = new_vars[i]; 
		if (current_var.hasOwnProperty('val_var')) {
			new_vars_str += current_var.val_var + ', '; 
			new_vars_str += current_var.lev_var; 
		} else {
			new_vars_str += current_var.pc_holder;  
		}
	}
	
	return new_vars_str; 
}; 
